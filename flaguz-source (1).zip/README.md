# FLAG.UZ

**Oʻzbekiston Davlat bayrogʻi tarixi va ramzlari** — "The Story Behind Our Flag"

FLAG.UZ — Oʻzbekiston Respublikasining Davlat bayrogʻi tarixi, rasmiy tuzilishi, huquqiy maqomi va ramziy talqinlarini oʻrganish uchun yaratilgan interaktiv taʼlimiy veb-platforma. Butun interfeys oʻzbek tilining lotin yozuvida (adabiy meʼyorlar asosida) tayyorlangan.

> **Eslatma:** FLAG.UZ mustaqil taʼlimiy loyiha boʻlib, u davlat organi tomonidan ishlab chiqilgan, tasdiqlangan yoki sertifikatlangan mahsulot sifatida taqdim etilmaydi.

---

## Maqsad va taʼlimiy vazifalar

- 9–11-sinf oʻquvchilariga Davlat bayrogʻining tarixini, qonuniy maqomini va ramziy mazmunini yetkazish
- Qonunda mustahkamlangan faktlar bilan keng tarqalgan ramziy talqinlarni **aniq ajratib koʻrsatish**
- Interaktiv bayroq, xronologiya va bilimlar sinovi orqali faol oʻzlashtirishni taʼminlash
- Milliy oʻzlik va fuqarolik masʼuliyati hissini uygʻotish

## Asosiy imkoniyatlar

| Boʻlim | Tavsif |
|---|---|
| **01 Bosh sahifa** | Hero-boʻlim: "Bir bayroq. Bir xalq. Bir oʻzlik." va qonunga mos bayroq tasviri |
| **02 Tarix va mustaqillik** | Interaktiv xronologiya (5 ta tasdiqlangan sana) yil-tanlash paneli bilan |
| **03 Ramzlarni anglash** | Interaktiv bayroq: 6 ta tanlanadigan element (ranglar, hoshiyalar, yarim oy, yulduzlar) — qonuniy xususiyatlar va talqinlar alohida bloklarda |
| **04 Fuqarolik masʼuliyati** | Bayroqning qonuniy maqomi, suverenitet, ehtirom va fuqarolik burchi |
| **05 Bilimlar sinovi** | 10 ta savolli test: darhol javob baho­lash, izohlar, progress, natija va qayta boshlash |
| **06 Yoshlar va kelajak** | Yoshlar uchun taʼlim, fan, innovatsiya va halol mehnat yoʻnalishlari |
| **Qoʻshimcha** | FAQ (10 savol), atamalar lugʻati, rasmiy manbalar, LOYIHA HAQIDA (tajriba maqomi + maxfiylik), tahrirlanadigan jamoa ismlari (localStorage) |
| **Vositalar** | Saytdan qidirish (Ctrl/Cmd+K), namoyish rejimi (sinf projektori uchun), mobil menyu |

## Texnik aniqlik

Bayroq tasviri **"Oʻzbekiston Respublikasining Davlat bayrogʻi toʻgʻrisida"gi Qonun**ga (1991-yil 18-noyabr, 407-XII-son) ilova qilingan rasmiy sxema asosida SVG koordinatalar bilan qurilgan:

- Nisbat 2:1 (250 × 125 sm), uchta teng 40 sm zolak, ikkita 2,5 sm qizil hoshiya
- Yarim oy: tashqi aylana Ø 30 sm, eng yaqin nuqtasi dastadan 20 sm, **qavariq tomoni dastaga qaratilgan**
- 12 ta besh burchakli yulduz, 3 qator: yuqorida 3, oʻrtada 4, pastda 5
- Bayroq hech qachon deformatsiya qilinmaydi, toʻlqinlanmaydi va animatsiya qilinmaydi

Asosiy manba: [lex.uz/uz/acts/-100122](https://lex.uz/uz/acts/-100122)

## Skrinshotlar

> 📷 **PLACEHOLDER** — `_screenshots/01-hero.png` — Bosh sahifa (hero-boʻlim va dastaga oʻrnatilgan bayroq)
>
> 📷 **PLACEHOLDER** — `_screenshots/02-timeline.png` — Tarix xronologiyasi boʻlimi
>
> 📷 **PLACEHOLDER** — `_screenshots/03-interactive-flag.png` — Interaktiv bayroq (element tanlangan holatda)
>
> 📷 **PLACEHOLDER** — `_screenshots/04-quiz.png` — Bilimlar sinovi savoli
>
> 📷 **PLACEHOLDER** — `_screenshots/05-quiz-result.png` — Test natijasi ekrani
>
> 📷 **PLACEHOLDER** — `_screenshots/06-presentation-mode.png` — Namoyish rejimi

*Skrinshotlarni olish:* saytni ishga tushirib (`bun run dev`), brauzerda `http://localhost:3000` oching va kerakli boʻlimlarni suratga oling, soʻngra ularni `_screenshots/` papkasiga joylashtiring.

## Texnologiyalar

- **Next.js 16** (App Router) + **TypeScript 5**
- **React 19**
- **Tailwind CSS 4** + shadcn/ui (New York) + Lucide icons
- Statik, butunlay mijoz tomonida ishlaydigan kontent (maʼlumotlar bazasi talab qilinmaydi)
- Qidiruv va test logikasi — xotirada, tashqi API chaqiruvisiz

## Oʻrnatish

Talablar: [Node.js 20+](https://nodejs.org) yoki [Bun](https://bun.sh)

```bash
# 1. Repozitoriyni klonlash
git clone https://github.com/<username>/flaguz.git
cd flaguz

# 2. Bogʻliqliklarni oʻrnatish
bun install        # yoki: npm install
```

## Ishga tushirish

```bash
# Ishlab chiqish rejimi (http://localhost:3000)
bun run dev        # yoki: npm run dev

# Ishlab chiqarish uchun yigʻish
bun run build      # yoki: npm run build

# Ishlab chiqarish serverini ishga tushirish
bun run start      # yoki: npm run start

# Kod sifatini tekshirish
bun run lint       # yoki: npm run lint
```

## Loyiha tuzilishi

```
flaguz/
├── src/
│   ├── app/
│   │   ├── layout.tsx        # Ildiz layout: shriftlar, metadata (uz tili)
│   │   ├── page.tsx          # Bitta sahifa: barcha boʻlimlar + qidiruv + namoyish rejimi
│   │   └── globals.css       # Ranglar palitrasi, animatsiyalar, reduced-motion qoidalari
│   ├── components/
│   │   ├── uzbekistan-flag.tsx   # Qonunga mos SVG bayroq (oddiy, dastali, interaktiv variantlar)
│   │   └── site/                 # Sayt boʻlimlari
│   │       ├── navbar.tsx        # Fiksrlangan header, mobil menyu
│   │       ├── hero.tsx          # 01 Bosh sahifa
│   │       ├── timeline.tsx      # 02 Tarix xronologiyasi
│   │       ├── symbols.tsx       # 03 Ramzlarni anglash
│   │       ├── responsibility.tsx# 04 Fuqarolik masʼuliyati
│   │       ├── quiz.tsx          # 05 Bilimlar sinovi
│   │       ├── youth.tsx         # 06 Yoshlar va kelajak
│   │       ├── extras.tsx        # FAQ, lugʻat, manbalar, LOYIHA HAQIDA
│   │       ├── footer.tsx        # Footer (muallif + AION belgisi)
│   │       ├── search-dialog.tsx # Ctrl/Cmd+K qidiruv
│   │       ├── presentation-bar.tsx # Namoyish rejimi paneli
│   │       ├── reveal.tsx        # Skroll animatsiyalari oʻrami
│   │       └── ui.tsx            # Umumiy boʻlim qoliplari
│   └── lib/
│       ├── content.ts        # BARCHA matnlar: xronologiya, ramzlar, 10 ta savol, FAQ, lugʻat, manbalar
│       └── utils.ts          # cn() yordamchisi
├── public/                   # Statik fayllar
└── package.json
```

Kontentni tahrirlash uchun `src/lib/content.ts` fayli yetarli — barcha matnlar shu faylda markazlashtirilgan.

## Deploy

Loyiha oddiy Next.js ilovasi — barcha mashhur platformalarda ishlaydi:

**Vercel (tavsiya etiladi)**
1. Repozitoriyni GitHub-ga yuklang
2. [vercel.com](https://vercel.com) → "New Project" → repozitoriyni ulang
3. Framework: *Next.js* (avtomatik aniqlanadi) → Deploy

**Boshqa platformalar (Netlify, Railway, VPS):**
```bash
bun run build
bun run start   # standalone server, PORT muhit oʻzgaruvchisini qoʻllab-quvvatlaydi
```

Statik eksport talab qilinadigan joyda `next.config.ts` ga `output: "export"` qoʻshish mumkin (barcha funksiyalar mijoz tomonida ishlagani uchun statik eksport toʻlaqonli ishlaydi).

## Maxfiylik va maʼlumotlar

Tekshirilgan holat (koddan mustaqil tekshirilgan):

- ❌ Kamera, mikrofon, joylashuv, kontaktlar yoki fayllarga kirish **soʻralmaydi** — kodda tegishli API chaqiruvlari umuman mavjud emas
- ❌ Roʻyxatdan oʻtish, hisob yaratish yoki autentifikatsiya **talab qilinmaydi**
- ❌ Reklama, trekerlar yoki uchinchi tomon analitikasi **ishlatilmaydi** (tashqi skriptlar yuklanmaydi)
- ✅ Yagona saqlanadigan maʼlumot — jamoa boʻlimiga kiritilgan ismlar, faqat brauzerning `localStorage` xotirasida (`flaguz-team-names` kaliti), serverga yuborilmaydi
- ⚠️ Loyiha joylashtirilgan hosting tomonidan standart texnik jurnal (IP, vaqt) yuritilishi mumkin — bu loyiha kodiga bogʻliq emas va maxfiylik bayonnomasida eʼtirof etilgan

Loyiha **tajriba (sinov) versiyasi** sifatida bepul taqdim etiladi va bosqichma-bosqich yangilanishi rejalashtirilgan.

## Muhim cheklovlar va kelgusi yaxshilanishlar

**Hozirgi cheklovlar:**
- Tajriba versiyasi — ayrim funksiyalar va dizayn kelgusida oʻzgarishi mumkin
- Qidiruv oddiy matn moslashtirishga asoslangan (morfologik analiz yoʻq)
- Koʻpsavatli (dark) mavjud hozircha yoʻq
- Test natijalari saqlanmaydi (faqat joriy sessiya)

**Rejalashtirilgan:**
- Qoʻshimcha savollar toʻplamlari va darajali testlar
- Rasm/foto materiallar bilan boyitilgan tarixiy boʻlim
- Nutq sintezi orqali matnni oʻqish (mavjud boʻlsa)
- Foydalanuvchi fikr-mulohazasi mexanizmi

## Mualliflik va havolalar

- **Muallif:** Made by [abdushukur.dev](https://abdushukur.dev)
- **Ekotizim:** Part of AION
- **Jamoa:** ZIYO — 1-guruh (4 nafar ishtirokchi; ismlar saytdagi "Loyiha haqida" boʻlimida kiritiladi)

**Rasmiy manbalar:**
- ["Oʻzbekiston Respublikasining Davlat bayrogʻi toʻgʻrisida"gi Qonun](https://lex.uz/uz/acts/-100122) (1991-yil 18-noyabr, 407-XII-son)
- [Oʻzbekiston Respublikasining Konstitutsiyasi](https://lex.uz/uz/docs/-6445145)
- [Qonunga kiritilgan 2023-yilgi oʻzgartirishlar](https://lex.uz/uz/docs/-6524722)

## Litsenziya

Tavsiya etilgan litsenziya — **MIT License** (qarang: `LICENSE` fayli). Litsenziyani rasman qoʻllashdan oldin loyiha muallifi uning shartlarini tasdiqlashi kerak. Agar boshqa litsenziya tanlansa, `LICENSE` faylini mos ravishda almashtiring.

## Disclaimer

FLAG.UZ — mustaqil taʼlimiy loyiha. U Oʻzbekiston Respublikasi davlat organlari tomonidan ishlab chiqilmagan, tasdiqlanmagan va moliyalashtirilmagan. Saytdagi rasmiy maʼlumotlar uchun yuqoridagi rasmiy manbalar asosiy havola boʻlib xizmat qiladi. Ramzlarning badiiy talqinlari qonun matnida belgilanmagan umumqabul qilingan izohlardir.
