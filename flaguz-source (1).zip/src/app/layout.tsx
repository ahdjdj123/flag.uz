import type { Metadata, Viewport } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin", "latin-ext"],
  display: "swap",
});

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin", "latin-ext"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "FLAG.UZ — Oʻzbekiston Davlat bayrogʻi tarixi va ramzlari",
  description:
    "Oʻzbekiston Respublikasining Davlat bayrogʻi tarixi, uning ramziy mazmuni, qonuniy maqomi va fuqarolik masʼuliyati haqidagi taʼlimiy platforma. ZIYO — 1-guruh loyihasi.",
  keywords: [
    "Oʻzbekiston davlat bayrogʻi",
    "bayroq tarixi",
    "bayroq ramzlari",
    "FLAG.UZ",
    "taʼlimiy loyiha",
    "ZIYO",
  ],
  authors: [{ name: "ZIYO — 1-guruh" }],
  openGraph: {
    title: "FLAG.UZ — Bir Bayroq. Bir Xalq. Bir Oʻzlik.",
    description:
      "Oʻzbekiston Respublikasining Davlat bayrogʻi tarixi, ramzlari va qonuniy maqomi haqidagi taʼlimiy platforma.",
    siteName: "FLAG.UZ",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#1E5AA8",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="uz" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${playfair.variable} font-sans antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
