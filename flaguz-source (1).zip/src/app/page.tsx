"use client";

import { useEffect, useState } from "react";
import { Navbar } from "@/components/site/navbar";
import { Hero } from "@/components/site/hero";
import { TimelineSection } from "@/components/site/timeline";
import { SymbolsSection } from "@/components/site/symbols";
import { ResponsibilitySection } from "@/components/site/responsibility";
import { QuizSection } from "@/components/site/quiz";
import { YouthSection } from "@/components/site/youth";
import {
  FaqSection,
  GlossarySection,
  ReferencesSection,
  ProjectSection,
} from "@/components/site/extras";
import { Footer } from "@/components/site/footer";
import { SearchDialog } from "@/components/site/search-dialog";
import { PresentationBar } from "@/components/site/presentation-bar";

export default function Page() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [presentation, setPresentation] = useState(false);
  const [activeId, setActiveId] = useState("bosh-sahifa");

  // Faol boʻlimni aniqlash (namoyish rejimi paneli uchun)
  useEffect(() => {
    const ids = [
      "bosh-sahifa",
      "tarix",
      "ramzlar",
      "majburiyat",
      "sinov",
      "yoshlar",
      "savollar",
      "lugat",
      "manbalar",
      "loyiha",
    ];
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setActiveId(e.target.id);
        }
      },
      { rootMargin: "-40% 0px -55% 0px", threshold: 0 }
    );
    for (const id of ids) {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    }
    return () => observer.disconnect();
  }, []);

  // Namoyish rejimi: sarlavha oʻlchamini oshirish (html elementiga class)
  useEffect(() => {
    document.documentElement.classList.toggle("presentation-mode", presentation);
    return () => document.documentElement.classList.remove("presentation-mode");
  }, [presentation]);

  // Ctrl+K / Cmd+K — qidiruvni ochish
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className={`flex min-h-screen flex-col bg-background ${presentation ? "pb-14" : ""}`}>
      <Navbar
        onOpenSearch={() => setSearchOpen(true)}
        presentation={presentation}
        onTogglePresentation={() => setPresentation((v) => !v)}
      />

      <main className="flex-1">
        <Hero />
        <TimelineSection />
        <SymbolsSection />
        <ResponsibilitySection />
        <QuizSection />
        <YouthSection />
        <FaqSection />
        <GlossarySection />
        <ReferencesSection />
        <ProjectSection />
      </main>

      <Footer />

      <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} />

      {presentation && (
        <PresentationBar
          activeId={activeId}
          onExit={() => setPresentation(false)}
        />
      )}
    </div>
  );
}
