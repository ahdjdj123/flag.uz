"use client";

import { useEffect, useState } from "react";
import {
  BookMarked,
  CameraOff,
  ExternalLink,
  FlaskConical,
  GraduationCap,
  Globe2,
  Info,
  MapPinOff,
  MicOff,
  ScrollText,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import {
  ABOUT_TEXT,
  EXPERIMENTAL_POINTS,
  FAQ,
  FREE_NOTICE,
  GLOSSARY,
  PRIVACY_DATA_NOTE,
  PRIVACY_LEGAL_NOTE,
  PRIVACY_POINTS,
  REFERENCES,
  TEAM,
} from "@/lib/content";
import { UzbekistanFlag } from "@/components/uzbekistan-flag";
import { SectionHeader, SectionShell } from "./ui";
import { Reveal } from "./reveal";

const ACCENTS = [
  "bg-brand-soft text-brand-deep",
  "bg-[#eef7f0] text-[#1c6b43]",
  "bg-[#fbf1f1] text-flag-red",
  "bg-[#f7f2e7] text-[#8a6d1f]",
];

/* ---------------- SAVOLLAR ---------------- */

export function FaqSection() {
  return (
    <SectionShell id="savollar" tone="ivory">
      <SectionHeader
        eyebrow="Savol-javob"
        title="Koʻp beriladigan savollar"
        lead="Platforma, uning tajriba maqomi, maxfiylik siyosati va manbalar boʻyicha eng koʻp soʻraladigan savollarga qisqa javoblar."
      />
      <div className="mx-auto max-w-3xl">
        <Accordion type="single" collapsible className="space-y-3">
          {FAQ.map((f, i) => (
            <AccordionItem
              key={i}
              value={`faq-${i}`}
              className="rounded-xl border border-line bg-card px-5 shadow-sm last:border-b"
            >
              <AccordionTrigger className="text-left text-[15px] font-semibold text-ink hover:no-underline">
                {f.question}
              </AccordionTrigger>
              <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                {f.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </SectionShell>
  );
}

/* ---------------- LUGʻAT ---------------- */

export function GlossarySection() {
  return (
    <SectionShell id="lugat" tone="white">
      <SectionHeader
        eyebrow="Atamalar lugʻati"
        title="Muhim atamalar"
        lead="Loyiha boʻylab uchraydigan asosiy tushunchalarning qisqa izohi."
      />
      <dl className="mx-auto grid max-w-5xl gap-4 sm:grid-cols-2">
        {GLOSSARY.map((g, i) => (
          <div
            key={g.term}
            className="rounded-2xl border border-line bg-background p-5 shadow-sm"
          >
            <dt className="flex items-center gap-2.5">
              <span
                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${ACCENTS[i % ACCENTS.length]}`}
                aria-hidden="true"
              >
                <BookMarked className="h-4 w-4" />
              </span>
              <span className="font-serif text-[17px] font-semibold text-ink">{g.term}</span>
            </dt>
            <dd className="mt-2.5 text-sm leading-relaxed text-muted-foreground">
              {g.definition}
            </dd>
          </div>
        ))}
      </dl>
    </SectionShell>
  );
}

/* ---------------- MANBALAR ---------------- */

export function ReferencesSection() {
  return (
    <SectionShell id="manbalar" tone="ivory">
      <SectionHeader
        eyebrow="Manbalar"
        title="Rasmiy manbalar"
        lead="Loyihadagi barcha faktlar quyidagi rasmiy hujjatlarga asoslangan. Havolalar faqat tekshirilgan manbalarga olib boradi."
      />
      <div className="mx-auto max-w-3xl space-y-4">
        {REFERENCES.map((r) => (
          <a
            key={r.title}
            href={r.url}
            target="_blank"
            rel="noopener noreferrer"
            className="focusable-ring group flex items-start gap-4 rounded-2xl border border-line bg-card p-5 shadow-sm transition-all hover:border-brand/40 hover:shadow-md"
          >
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
              <ScrollText className="h-5 w-5" />
            </span>
            <span className="min-w-0">
              <span className="block font-semibold text-ink group-hover:text-brand-deep">
                {r.title}
              </span>
              <span className="mt-1 block text-sm text-muted-foreground">{r.meta}</span>
              <span className="mt-1.5 inline-flex items-center gap-1 text-xs font-medium text-brand">
                {r.url.replace("https://", "")}
                <ExternalLink className="h-3 w-3" />
              </span>
            </span>
          </a>
        ))}
        <p className="rounded-xl bg-muted p-4 text-xs leading-relaxed text-muted-foreground">
          Eslatma: loyihada qonunning rasmiy talqinlari bilan umumqabul qilingan ramziy
          izohlar ajratib koʻrsatilgan. Ramzlarning badiiy talqinlari rasmiy hujjat
          matnida keltirilmaydi. Huquqiy masalalarda rasmiy manbalarga murojaat qiling.
        </p>
      </div>
    </SectionShell>
  );
}

/* ---------------- LOYIHA HAQIDA ---------------- */

const TEAM_STORAGE_KEY = "flaguz-team-names";

function TeamMemberCard({
  role,
  index,
  name,
  onChange,
}: {
  role: string;
  index: number;
  name: string;
  onChange: (v: string) => void;
}) {
  return (
    <article className="rounded-2xl border border-line bg-background p-5 text-center shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
      <span
        className={`mx-auto flex h-12 w-12 items-center justify-center rounded-full text-base font-bold ${ACCENTS[index % ACCENTS.length]}`}
        aria-hidden="true"
      >
        {index + 1}
      </span>
      <label className="mt-3 block text-xs font-semibold leading-snug text-brand">
        {role}
      </label>
      <Input
        value={name}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Ism Familiya"
        aria-label={`${role} — ism va familiya`}
        className="mt-2 h-9 border-line bg-white text-center text-sm font-semibold text-ink"
      />
    </article>
  );
}

export function ProjectSection() {
  // Jamoa aʼzolari ismlari — tahrirlanadigan maydonlar (faqat qurilmada saqlanadi)
  const [names, setNames] = useState<string[]>(TEAM.map(() => ""));

  useEffect(() => {
    // Saqlangan ismlarni asinxron oʻqish — hydration va kaskad renderlardan saqlanish uchun
    const t = window.setTimeout(() => {
      try {
        const raw = window.localStorage.getItem(TEAM_STORAGE_KEY);
        if (raw) {
          const saved: unknown = JSON.parse(raw);
          if (Array.isArray(saved) && saved.length === TEAM.length) {
            setNames(saved.map((v) => (typeof v === "string" ? v : "")));
          }
        }
      } catch {
        /* localStorage mavjud boʻlmasligi mumkin — bu xatoga emas */
      }
    }, 0);
    return () => window.clearTimeout(t);
  }, []);

  const saveName = (i: number, v: string) => {
    setNames((prev) => {
      const next = [...prev];
      next[i] = v;
      try {
        window.localStorage.setItem(TEAM_STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* yozib boʻlmasa ham ilova ishlashda davom etadi */
      }
      return next;
    });
  };

  return (
    <SectionShell id="loyiha" tone="white">
      <SectionHeader
        eyebrow="Loyiha haqida"
        title="FLAG.UZ — tajribaviy taʼlimiy platforma"
        lead="Platformaning maqsadi, hozirgi rivojlanish bosqichi, foydalanish shartlari va maxfiylik yondashuvi haqida toʻliq maʼlumot."
      />

      <div className="mx-auto max-w-4xl space-y-6">
        {/* Nima uchun yaratilgan */}
        <Reveal>
          <div className="rounded-3xl border border-line bg-background p-6 shadow-sm md:p-8">
            <h3 className="flex items-center gap-2.5 font-serif text-xl font-semibold text-ink">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-soft text-brand">
                <Info className="h-4.5 w-4.5" />
              </span>
              Platforma haqida
            </h3>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground md:text-[15px]">
              {ABOUT_TEXT}
            </p>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground md:text-[15px]">
              Platforma taʼlimiy maqsadlar, sinf namoyishlari va kelgusi
              takomillashtirishlar uchun fikr-mulohaza yigʻish uchun xizmat qiladi.
            </p>
            <p className="mt-5 rounded-xl border border-emerald-brand/20 bg-[#eef7f0] px-4 py-3 text-sm font-semibold text-[#1c6b43]">
              {FREE_NOTICE}
            </p>
          </div>
        </Reveal>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Tajriba maqomi */}
          <Reveal delay={80}>
            <div className="h-full rounded-3xl border border-line bg-background p-6 shadow-sm">
              <h3 className="flex items-center gap-2.5 font-serif text-xl font-semibold text-ink">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#f7f2e7] text-[#8a6d1f]">
                  <FlaskConical className="h-4.5 w-4.5" />
                </span>
                Tajriba versiyasi maqomi
              </h3>
              <ul className="mt-4 space-y-2.5">
                {EXPERIMENTAL_POINTS.map((t) => (
                  <li
                    key={t}
                    className="flex gap-2.5 text-[13.5px] leading-relaxed text-muted-foreground"
                  >
                    <span
                      className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-[#c8a24a]"
                      aria-hidden="true"
                    />
                    {t}
                  </li>
                ))}
              </ul>
              <p className="mt-4 rounded-lg bg-muted p-3 text-xs leading-relaxed text-muted-foreground">
                FLAG.UZ davlat organi tomonidan ishlab chiqilgan, tasdiqlangan yoki
                sertifikatlangan mahsulot sifatida taqdim etilmaydi.
              </p>
            </div>
          </Reveal>

          {/* Maxfiylik */}
          <Reveal delay={160}>
            <div className="h-full rounded-3xl border border-line bg-background p-6 shadow-sm">
              <h3 className="flex items-center gap-2.5 font-serif text-xl font-semibold text-ink">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#eef7f0] text-[#1c6b43]">
                  <ShieldCheck className="h-4.5 w-4.5" />
                </span>
                Maxfiylik va maʼlumotlar
              </h3>
              <ul className="mt-4 space-y-2.5">
                <li className="flex items-start gap-2.5 text-[13.5px] leading-relaxed text-muted-foreground">
                  <CameraOff className="mt-0.5 h-4 w-4 shrink-0 text-[#1c6b43]" />
                  Platforma kamera ruxsatini soʻramaydi va kameradan foydalanmaydi.
                </li>
                <li className="flex items-start gap-2.5 text-[13.5px] leading-relaxed text-muted-foreground">
                  <MicOff className="mt-0.5 h-4 w-4 shrink-0 text-[#1c6b43]" />
                  Mikrofonga kirish talab qilinmaydi.
                </li>
                <li className="flex items-start gap-2.5 text-[13.5px] leading-relaxed text-muted-foreground">
                  <MapPinOff className="mt-0.5 h-4 w-4 shrink-0 text-[#1c6b43]" />
                  Joylashuv maʼlumotlariga kirish soʻralmaydi.
                </li>
                {PRIVACY_POINTS.slice(2).map((t) => (
                  <li
                    key={t}
                    className="flex gap-2.5 text-[13.5px] leading-relaxed text-muted-foreground"
                  >
                    <span
                      className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-flag-green"
                      aria-hidden="true"
                    />
                    {t}
                  </li>
                ))}
              </ul>
              <p className="mt-4 rounded-lg bg-muted p-3 text-xs leading-relaxed text-muted-foreground">
                {PRIVACY_DATA_NOTE}
              </p>
              <p className="mt-2 rounded-lg bg-muted p-3 text-xs leading-relaxed text-muted-foreground">
                {PRIVACY_LEGAL_NOTE}
              </p>
            </div>
          </Reveal>
        </div>

        {/* Jamoa */}
        <Reveal delay={120}>
          <div className="rounded-3xl border border-line bg-background p-6 shadow-sm md:p-8">
            <h3 className="flex items-center justify-center gap-2.5 font-serif text-xl font-semibold text-ink">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-soft text-brand">
                <Users className="h-4.5 w-4.5" />
              </span>
              ZIYO — 1-guruh jamoasi
            </h3>
            <p className="mx-auto mt-3 max-w-2xl text-center text-sm leading-relaxed text-muted-foreground">
              Loyiha toʻrt nafar ishtirokchi tomonidan tayyorlandi. Ismlarni pastdagi
              maydonlarga kiritishingiz mumkin — ular shu qurilmada saqlanadi.
            </p>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {TEAM.map((m, i) => (
                <TeamMemberCard
                  key={m.role}
                  role={m.role}
                  index={i}
                  name={names[i]}
                  onChange={(v) => saveName(i, v)}
                />
              ))}
            </div>
          </div>
        </Reveal>

        {/* Missiya */}
        <Reveal delay={160}>
          <div className="flex flex-col items-center gap-5 rounded-3xl border border-line bg-brand-soft/40 p-6 sm:flex-row md:p-8">
            <span className="flex h-16 w-24 shrink-0 items-center justify-center rounded-xl bg-white shadow-sm ring-1 ring-black/5">
              <UzbekistanFlag className="h-auto w-16 rounded-[2px]" />
            </span>
            <div className="text-center sm:text-left">
              <h3 className="flex items-center justify-center gap-2 font-serif text-xl font-semibold text-ink sm:justify-start">
                <GraduationCap className="h-5 w-5 text-brand" />
                FLAG.UZ — “Bayroq ortidagi hikoya”
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Loyiha maqsadi — tengdoshlarimizga Davlat bayrogʻining tarixi, qonuniy
                maqomi va ramziy mazmunini shakllantirish orqali milliy oʻzlik va
                fuqarolik javobgarligi hissini uygʻotish. “Bir Bayroq. Bir Xalq. Bir
                Oʻzlik.”
              </p>
              <p className="mt-3 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <Globe2 className="h-3.5 w-3.5 text-brand" />
                AION loyiha ekotizimi bir qismi
                <Sparkles className="h-3.5 w-3.5 text-[#c8a24a]" />
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </SectionShell>
  );
}
