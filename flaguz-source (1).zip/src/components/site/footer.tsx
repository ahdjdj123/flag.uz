"use client";

import { UzbekistanFlag } from "@/components/uzbekistan-flag";
import { SECTIONS, scrollToSection } from "./navbar";
import { LAW_SOURCE } from "@/lib/content";

export function Footer() {
  return (
    <footer className="mt-auto border-t border-line bg-ink text-white">
      <div className="mx-auto w-full max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-[1.2fr_0.8fr_1fr]">
          {/* Brend */}
          <div>
            <div className="flex items-center gap-2.5">
              <span className="block w-10 overflow-hidden rounded-[3px] ring-1 ring-white/20">
                <UzbekistanFlag className="block h-auto w-full" label="" />
              </span>
              <span className="font-serif text-2xl font-bold tracking-wide">
                FLAG<span className="text-[#7fa8d9]">.UZ</span>
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-white/70">
              Oʻzbekiston Respublikasining Davlat bayrogʻi tarixi va ramzlari haqidagi
              taʼlimiy platforma.
            </p>
            <p className="mt-4 font-serif text-sm font-semibold tracking-[0.14em] text-white/90 uppercase">
              Bir bayroq. Bir xalq. Bir oʻzlik.
            </p>
          </div>

          {/* Navigatsiya */}
          <nav aria-label="Sayt xaritasi">
            <p className="text-xs font-semibold tracking-[0.2em] text-white/50 uppercase">
              Boʻlimlar
            </p>
            <ul className="mt-4 space-y-2.5">
              {SECTIONS.map((s) => (
                <li key={s.id}>
                  <button
                    onClick={() => scrollToSection(s.id)}
                    className="focusable-ring rounded text-sm text-white/80 transition-colors hover:text-white"
                  >
                    {s.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Manba */}
          <div>
            <p className="text-xs font-semibold tracking-[0.2em] text-white/50 uppercase">
              Asosiy manba
            </p>
            <a
              href={LAW_SOURCE.url}
              target="_blank"
              rel="noopener noreferrer"
              className="focusable-ring mt-4 block rounded-lg border border-white/15 bg-white/5 p-4 transition-colors hover:bg-white/10"
            >
              <span className="block text-sm font-semibold text-white">{LAW_SOURCE.name}</span>
              <span className="mt-1 block text-xs text-white/60">{LAW_SOURCE.meta}</span>
              <span className="mt-2 block text-xs font-medium text-[#7fa8d9]">
                lex.uz/uz/acts/-100122
              </span>
            </a>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-white/50 sm:flex-row">
          <p>© {new Date().getFullYear()} FLAG.UZ — ZIYO — 1-guruh taʼlimiy loyihasi.</p>
          <p>Bayroq tasviri qonunga ilova qilingan rasmiy sxema asosida tayyorlandi.</p>
        </div>

        {/* Muallif belgisi — AION ekotizimi */}
        <div
          className="mt-6 flex flex-col items-center gap-1.5 border-t border-white/10 pt-5 pb-1 text-center"
          aria-label="Loyiha muallifi"
        >
          <p className="text-sm font-semibold tracking-wide text-white/85">
            Made by{" "}
            <a
              href="https://abdushukur.dev"
              target="_blank"
              rel="noopener noreferrer"
              className="focusable-ring rounded underline decoration-white/30 underline-offset-4 transition-colors hover:text-white hover:decoration-white/70"
            >
              abdushukur.dev
            </a>
          </p>
          <p
            className="text-[11px] font-medium uppercase tracking-[0.28em] text-white/45"
          >
            Part of AION
          </p>
        </div>
      </div>
    </footer>
  );
}
