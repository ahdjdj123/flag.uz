"use client";

import { ArrowRight, History, Star } from "lucide-react";
import { FlagOnPole } from "@/components/uzbekistan-flag";
import { scrollToSection } from "./navbar";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section
      id="bosh-sahifa"
      className="relative overflow-hidden bg-ivory pt-28 pb-16 md:pt-36 md:pb-24 scroll-mt-0"
    >
      {/* Nozik dekorativ fon */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="absolute -top-24 -right-24 h-96 w-96 rounded-full bg-brand-soft/50 blur-3xl" />
        <div className="absolute top-1/2 -left-32 h-72 w-72 rounded-full bg-[#eef3ee] blur-3xl" />
        <svg
          className="absolute right-[8%] top-16 hidden h-24 w-24 text-brand/10 lg:block"
          viewBox="0 0 100 100"
          fill="currentColor"
        >
          <path d="M50 0l10 40 40 10-40 10-10 40-10-40L0 50l40-10z" />
        </svg>
        <svg
          className="absolute bottom-10 left-[6%] hidden h-16 w-16 text-[#c8a24a]/25 md:block"
          viewBox="0 0 100 100"
          fill="currentColor"
        >
          <path d="M50 0l10 40 40 10-40 10-10 40-10-40L0 50l40-10z" />
        </svg>
      </div>

      <div className="relative mx-auto grid w-full max-w-6xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:gap-8 lg:px-8">
        {/* Matn */}
        <div>
          <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-brand/20 bg-white px-4 py-1.5 text-xs font-semibold tracking-[0.18em] text-brand uppercase shadow-sm">
            Taʼlimiy loyiha · ZIYO — 1-guruh
          </p>
          <h1 className="font-serif text-4xl leading-[1.08] font-bold text-ink sm:text-5xl lg:text-[3.4rem]">
            Bir bayroq. Bir xalq.
            <span className="mt-1 block text-brand">Bir oʻzlik.</span>
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
            Oʻzbekiston Respublikasining Davlat bayrogʻi tarixi, uning ramziy mazmuni va
            davlat mustaqilligini ifodalashdagi oʻrni bilan tanishing.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button
              size="lg"
              onClick={() => scrollToSection("ramzlar")}
              className="gap-2 bg-brand px-6 text-white shadow-md hover:bg-brand-deep"
            >
              Bayroqni oʻrganish
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => scrollToSection("tarix")}
              className="gap-2 border-brand/30 bg-white px-6 text-brand-deep hover:bg-brand-soft hover:text-brand-deep"
            >
              <History className="h-4 w-4" />
              Tarixga nazar
            </Button>
          </div>

          <dl className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-line pt-6">
            {[
              { v: "18.11.1991", k: "Qabul qilingan sana" },
              { v: "2:1", k: "Bayroq nisbati" },
              { v: "12", k: "Yulduz, 3 qatorda" },
            ].map((s) => (
              <div key={s.k}>
                <dt className="sr-only">{s.k}</dt>
                <dd className="font-serif text-lg font-bold text-ink md:text-xl">{s.v}</dd>
                <dd className="mt-0.5 text-xs text-muted-foreground md:text-[13px]">{s.k}</dd>
              </div>
            ))}
          </dl>
        </div>

        {/* Bayroq */}
        <div className="relative">
          <div className="mx-auto w-full max-w-[540px]">
            <FlagOnPole className="h-auto w-full" />
          </div>
          <p className="mt-4 flex items-center justify-center gap-2 text-center text-xs text-muted-foreground">
            <Star className="h-3.5 w-3.5 text-[#c8a24a]" />
            Oʻzbekiston Respublikasining Davlat bayrogʻi — rasmiy sxema asosida
            <Star className="h-3.5 w-3.5 text-[#c8a24a]" />
          </p>
        </div>
      </div>
    </section>
  );
}
