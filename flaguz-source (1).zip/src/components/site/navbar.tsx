"use client";

import { useEffect, useState } from "react";
import { Menu, Presentation, Search, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { UzbekistanFlag } from "@/components/uzbekistan-flag";
import { Button } from "@/components/ui/button";

export const SECTIONS = [
  { id: "bosh-sahifa", label: "Bosh sahifa" },
  { id: "tarix", label: "Tarix" },
  { id: "ramzlar", label: "Ramzlar" },
  { id: "majburiyat", label: "Majburiyat" },
  { id: "sinov", label: "Bilim sinovi" },
  { id: "yoshlar", label: "Yoshlar" },
  { id: "loyiha", label: "Loyiha" },
] as const;

export function scrollToSection(id: string) {
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

export function Navbar({
  onOpenSearch,
  presentation,
  onTogglePresentation,
}: {
  onOpenSearch: () => void;
  presentation: boolean;
  onTogglePresentation: () => void;
}) {
  const [active, setActive] = useState<string>("bosh-sahifa");
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setActive(e.target.id);
          }
        }
      },
      { rootMargin: "-40% 0px -55% 0px", threshold: 0 }
    );
    for (const s of SECTIONS) {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    }
    return () => observer.disconnect();
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-line/80 bg-ivory/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
        {/* Logotip */}
        <button
          onClick={() => scrollToSection("bosh-sahifa")}
          className="focusable-ring flex items-center gap-2.5 rounded-md"
          aria-label="FLAG.UZ — bosh sahifaga oʻtish"
        >
          <span className="block w-9 overflow-hidden rounded-[3px] shadow-sm ring-1 ring-black/10">
            <UzbekistanFlag className="block h-auto w-full" label="" />
          </span>
          <span className="font-serif text-xl font-bold tracking-wide text-ink">
            FLAG<span className="text-brand">.UZ</span>
          </span>
        </button>

        {/* Ish stoli navigatsiyasi */}
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Asosiy navigatsiya">
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              onClick={() => scrollToSection(s.id)}
              className={cn(
                "focusable-ring relative whitespace-nowrap rounded-md px-3 py-2 text-sm font-medium transition-colors",
                active === s.id
                  ? "text-brand"
                  : "text-muted-foreground hover:text-ink"
              )}
              aria-current={active === s.id ? "true" : undefined}
            >
              {s.label}
              <span
                className={cn(
                  "absolute inset-x-3 -bottom-[13px] h-0.5 rounded-full bg-brand transition-opacity",
                  active === s.id ? "opacity-100" : "opacity-0"
                )}
                aria-hidden="true"
              />
            </button>
          ))}
        </nav>

        {/* Oʻng tomon: qidiruv + namoyish rejimi */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onOpenSearch}
            className="gap-2 border-line bg-white text-ink hover:bg-brand-soft hover:text-brand-deep"
            aria-label="Saytdan qidirish"
          >
            <Search className="h-4 w-4" />
            <span className="hidden md:inline">Qidirish</span>
          </Button>
          <Button
            size="sm"
            onClick={onTogglePresentation}
            variant={presentation ? "default" : "secondary"}
            className={cn(
              "gap-2",
              presentation
                ? "bg-brand text-white hover:bg-brand-deep"
                : "bg-white text-ink hover:bg-brand-soft hover:text-brand-deep"
            )}
            aria-pressed={presentation}
          >
            <Presentation className="h-4 w-4" />
            <span className="hidden md:inline">Namoyish</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden text-ink"
            onClick={() => setMobileOpen((v) => !v)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? "Menyuni yopish" : "Menyuni ochish"}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobil menyu */}
      {mobileOpen && (
        <nav
          className="border-t border-line bg-ivory px-4 pb-4 pt-2 lg:hidden"
          aria-label="Mobil navigatsiya"
        >
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                scrollToSection(s.id);
                setMobileOpen(false);
              }}
              className={cn(
                "block w-full rounded-md px-3 py-2.5 text-left text-[15px] font-medium",
                active === s.id ? "bg-brand-soft text-brand-deep" : "text-ink hover:bg-muted"
              )}
            >
              {s.label}
            </button>
          ))}
        </nav>
      )}
    </header>
  );
}
