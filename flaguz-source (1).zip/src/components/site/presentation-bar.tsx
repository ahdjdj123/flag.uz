"use client";

import { ChevronLeft, ChevronRight, Presentation, X } from "lucide-react";
import { SECTIONS, scrollToSection } from "./navbar";

export function PresentationBar({
  activeId,
  onExit,
}: {
  activeId: string;
  onExit: () => void;
}) {
  const idx = Math.max(
    0,
    SECTIONS.findIndex((s) => s.id === activeId)
  );
  const current = SECTIONS[idx];
  const prev = SECTIONS[idx - 1];
  const next = SECTIONS[idx + 1];

  return (
    <div
      className="fixed inset-x-0 bottom-0 z-40 border-t border-brand/20 bg-ink/95 text-white shadow-lg backdrop-blur"
      role="region"
      aria-label="Namoyish rejimi boshqaruvi"
    >
      <div className="mx-auto flex h-14 w-full max-w-6xl items-center justify-between gap-3 px-4 pb-[env(safe-area-inset-bottom)] sm:px-6 lg:px-8">
        <span className="flex min-w-0 items-center gap-2 text-sm font-medium">
          <Presentation className="h-4 w-4 shrink-0 text-[#c8a24a]" />
          <span className="truncate">
            <span className="text-white/60">{idx + 1} / {SECTIONS.length} — </span>
            {current.label}
          </span>
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => prev && scrollToSection(prev.id)}
            disabled={!prev}
            className="focusable-ring rounded-md border border-white/20 px-3 py-1.5 text-sm disabled:opacity-40 hover:bg-white/10"
            aria-label="Oldingi boʻlim"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            onClick={() => next && scrollToSection(next.id)}
            disabled={!next}
            className="focusable-ring rounded-md border border-white/20 px-3 py-1.5 text-sm disabled:opacity-40 hover:bg-white/10"
            aria-label="Keyingi boʻlim"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <button
            onClick={onExit}
            className="focusable-ring ml-1 flex items-center gap-1.5 rounded-md bg-white px-3 py-1.5 text-sm font-semibold text-ink hover:bg-white/90"
            aria-label="Namoyish rejimidan chiqish"
          >
            <X className="h-4 w-4" />
            <span className="hidden sm:inline">Chiqish</span>
          </button>
        </div>
      </div>
    </div>
  );
}
