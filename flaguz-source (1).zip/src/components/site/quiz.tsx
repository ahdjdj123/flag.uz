"use client";

import { useMemo, useState } from "react";
import { BadgeCheck, ChevronRight, RotateCcw, Trophy, XCircle } from "lucide-react";
import { QUIZ } from "@/lib/content";
import { SectionHeader, SectionShell } from "./ui";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

type Answer = number | null;

export function QuizSection() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>(Array(QUIZ.length).fill(null));
  const [finished, setFinished] = useState(false);

  const q = QUIZ[step];
  const chosen = answers[step];
  const answered = chosen !== null;
  const isLast = step === QUIZ.length - 1;

  const score = useMemo(
    () => answers.reduce<number>((acc, a, i) => (a === QUIZ[i].correct ? acc + 1 : acc), 0),
    [answers]
  );

  const select = (idx: number) => {
    if (answered) return;
    setAnswers((prev) => {
      const next = [...prev];
      next[step] = idx;
      return next;
    });
  };

  const nextStep = () => {
    if (isLast) {
      setFinished(true);
    } else {
      setStep((s) => s + 1);
    }
  };

  const restart = () => {
    setStep(0);
    setAnswers(Array(QUIZ.length).fill(null));
    setFinished(false);
  };

  const resultMessage =
    score === QUIZ.length
      ? "Aʼlo! Bayroq haqidagi bilimingiz juda mustahkam — siz haqiqiy bilimdon fuqarosiz."
      : score >= 8
        ? "Juda yaxshi natija! Ayrim mavzular boʻyicha materiallarni yana bir bor takrorlab koʻring."
        : score >= 5
          ? "Yaxshi boshlanish. “Ramzlarni anglash” boʻlimini qayta oʻrganib, qaytadan urinib koʻring."
          : "Tashvishlanmang — bayroq tarixi va ramzlari boʻlimlarini bir marotaba oʻzlashtirib, qaytadan sinab koʻring.";

  return (
    <SectionShell id="sinov" tone="ivory">
      <SectionHeader
        index="05"
        eyebrow="Bilimlar sinovi"
        title="Oʻz bilimingizni sinab koʻring"
        lead="Davlat bayrogʻi boʻyicha 10 ta savol. Har bir javobdan soʻng toʻgʻri javob va qisqa izoh koʻrsatiladi."
      />

      {finished ? (
        /* ---------- Natija ekran ---------- */
        <div className="mx-auto max-w-2xl rounded-3xl border border-line bg-card p-8 text-center shadow-sm">
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-brand-soft">
            <Trophy className="h-8 w-8 text-brand" />
          </span>
          <p className="mt-5 text-sm font-semibold tracking-[0.2em] text-brand uppercase">
            Natijangiz
          </p>
          <p className="mt-2 font-serif text-5xl font-bold text-ink">
            {score} <span className="text-2xl text-muted-foreground">/ {QUIZ.length}</span>
          </p>
          <div className="mx-auto mt-5 h-2.5 w-full max-w-sm overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-gradient-to-r from-flag-blue to-flag-green transition-all duration-700"
              style={{ width: `${(score / QUIZ.length) * 100}%` }}
            />
          </div>
          <p className="mt-5 text-sm leading-relaxed text-muted-foreground md:text-base">
            {resultMessage}
          </p>

          {/* Javoblar koʻrinishi */}
          <ul className="mt-8 space-y-2 text-left">
            {QUIZ.map((qq, i) => {
              const ok = answers[i] === qq.correct;
              return (
                <li
                  key={i}
                  className={cn(
                    "flex items-start gap-2.5 rounded-xl border p-3 text-sm",
                    ok ? "border-flag-green/25 bg-[#f2f9f4]" : "border-flag-red/25 bg-[#fbf1f1]"
                  )}
                >
                  {ok ? (
                    <BadgeCheck className="mt-0.5 h-4.5 w-4.5 shrink-0 text-flag-green" />
                  ) : (
                    <XCircle className="mt-0.5 h-4.5 w-4.5 shrink-0 text-flag-red" />
                  )}
                  <div>
                    <p className="font-medium text-ink">
                      {i + 1}. {qq.question}
                    </p>
                    <p className="mt-1 text-[13px] text-muted-foreground">
                      Toʻgʻri javob: <span className="font-semibold text-ink">{qq.options[qq.correct]}</span>
                    </p>
                  </div>
                </li>
              );
            })}
          </ul>

          <Button
            size="lg"
            onClick={restart}
            className="mt-8 gap-2 bg-brand px-8 text-white hover:bg-brand-deep"
          >
            <RotateCcw className="h-4 w-4" />
            Qaytadan boshlash
          </Button>
        </div>
      ) : (
        /* ---------- Savol ekran ---------- */
        <div className="mx-auto max-w-2xl">
          {/* Progress */}
          <div className="mb-6">
            <div className="mb-2 flex items-center justify-between text-sm font-medium text-muted-foreground">
              <span>
                Savol <span className="font-bold text-ink">{step + 1}</span> / {QUIZ.length}
              </span>
              <span>
                Toʻgʻri javoblar: <span className="font-bold text-ink">{score}</span>
              </span>
            </div>
            <div
              className="h-2 w-full overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-valuenow={Math.round(((step + 1) / QUIZ.length) * 100)}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="Test progressi"
            >
              <div
                className="h-full rounded-full bg-brand transition-all duration-500"
                style={{ width: `${((step + 1) / QUIZ.length) * 100}%` }}
              />
            </div>
          </div>

          <div
            key={step}
            className="rounded-3xl border border-line bg-card p-6 shadow-sm md:p-8 animate-in fade-in slide-in-from-bottom-2 duration-300"
          >
            <h3 className="font-serif text-xl font-semibold leading-snug text-ink md:text-2xl">
              {q.question}
            </h3>

            <div className="mt-6 space-y-3" role="group" aria-label="Javob variantlari">
              {q.options.map((opt, idx) => {
                const isCorrect = idx === q.correct;
                const isChosen = chosen === idx;
                return (
                  <button
                    key={idx}
                    onClick={() => select(idx)}
                    disabled={answered}
                    aria-pressed={isChosen}
                    className={cn(
                      "focusable-ring flex w-full items-center gap-3 rounded-xl border p-4 text-left text-[15px] transition-all",
                      !answered &&
                        "border-line bg-background hover:border-brand/50 hover:bg-brand-soft/60",
                      answered && isCorrect && "border-flag-green bg-[#eef8f1]",
                      answered && isChosen && !isCorrect && "border-flag-red bg-[#fdf0f0]",
                      answered && !isCorrect && !isChosen && "border-line bg-background opacity-60"
                    )}
                  >
                    <span
                      className={cn(
                        "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-sm font-bold",
                        !answered && "border-line bg-white text-brand",
                        answered && isCorrect && "border-flag-green bg-flag-green text-white",
                        answered && isChosen && !isCorrect && "border-flag-red bg-flag-red text-white",
                        answered && !isCorrect && !isChosen && "border-line bg-white text-muted-foreground"
                      )}
                    >
                      {["A", "B", "C", "D"][idx]}
                    </span>
                    <span className="font-medium text-ink">{opt}</span>
                  </button>
                );
              })}
            </div>

            {answered && (
              <div
                className={cn(
                  "mt-5 animate-in fade-in slide-in-from-bottom-1 rounded-xl border p-4 duration-300",
                  chosen === q.correct
                    ? "border-flag-green/30 bg-[#eef8f1]"
                    : "border-flag-red/30 bg-[#fdf0f0]"
                )}
                aria-live="polite"
              >
                <p
                  className={cn(
                    "flex items-center gap-2 text-sm font-bold",
                    chosen === q.correct ? "text-[#1c6b43]" : "text-flag-red"
                  )}
                >
                  {chosen === q.correct ? (
                    <>
                      <BadgeCheck className="h-4.5 w-4.5" /> Toʻgʻri javob!
                    </>
                  ) : (
                    <>
                      <XCircle className="h-4.5 w-4.5" /> Afsus, bu javob toʻgʻri emas.
                    </>
                  )}
                </p>
                <p className="mt-2 text-sm leading-relaxed text-ink">{q.explanation}</p>
              </div>
            )}

            <div className="mt-6 flex justify-end">
              <Button
                size="lg"
                onClick={nextStep}
                disabled={!answered}
                className="gap-2 bg-brand px-7 text-white hover:bg-brand-deep disabled:opacity-50"
              >
                {isLast ? "Natijani koʻrish" : "Keyingi savol"}
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </SectionShell>
  );
}
