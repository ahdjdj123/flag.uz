"use client";

import {
  Flag,
  Globe2,
  GraduationCap,
  HeartHandshake,
  Landmark,
  Scale,
  Sprout,
  Users,
} from "lucide-react";
import { SectionHeader, SectionShell } from "./ui";
import { LAW_SOURCE } from "@/lib/content";

const LEGAL_CARDS = [
  {
    icon: Landmark,
    title: "Davlat suverenitetining ramzi",
    text: "Davlat bayrogʻi Oʻzbekistonning mustaqil davlat ekanini ifodalaydi. U davlatning ichki hayotida va xalqaro maydonda uning nomidan gapiruvchi rasmiy belgidir.",
  },
  {
    icon: Globe2,
    title: "Xalqaro maydondagi vakillik",
    text: "Birlashgan Millatlar Tashkiloti va boshqa xalqaro tashkilotlar, davlat tashriflari hamda rasmiy sport musobaqalarida Oʻzbekistonni aynan Davlat bayrogʻi ifodalaydi.",
  },
  {
    icon: Scale,
    title: "Qonun bilan belgilangan maqom",
    text: "Bayroqning tuzilishi, oʻlchamlari, ishlatish tartibi va muhofazasi 1991-yil 18-noyabrdagi Qonun bilan mustahkamlangan. Bu maqom Konstitutsiya bilan himoya qilinadi.",
  },
  {
    icon: HeartHandshake,
    title: "Ehtirom — fuqaroning burchi",
    text: "Davlat ramzlariga ehtiromli munosabat har bir fuqaroning burchidir. Bayroqni kamsituvchi harakatlar qonunchilik bilan taqiqlangan.",
  },
];

const CIVIC_ITEMS = [
  {
    icon: GraduationCap,
    title: "Sifatli taʼlim",
    text: "Bilim — bayroq sharafini oshiruvchi eng ishonchli yoʻl. Har bir oʻquvchi, talaba davlat ramziga boʻlgan hurmatni bilimi bilan koʻrsatadi.",
  },
  {
    icon: Flag,
    title: "Halol mehnat",
    text: "Oʻz ishiga masʼuliyat bilan yondashgan har bir mutaxassis Vatan obroʻsiga qoʻshgan hissasi bilan bayroqning maʼnosini boyitadi.",
  },
  {
    icon: Sprout,
    title: "Shaxsiy javobgarlik",
    text: "Oʻz vaʼdasiga sodiq qolish, qonunlarga rioya qilish va atrof-muhitga eʼtiborli boʻlish — milliy gʻururning kundalik namoyonidir.",
  },
  {
    icon: Users,
    title: "Jamiyatga hurmat",
    text: "Mehmondoʻstlik, oqkoʻngillik va jamoaviy hayotda bir-biriga yordam — bayroq ostida yashayotganimizning haqiqiy koʻrinishi.",
  },
];

export function ResponsibilitySection() {
  return (
    <SectionShell id="majburiyat" tone="white">
      <SectionHeader
        index="04"
        eyebrow="Davlat ramzi va fuqarolik masʼuliyati"
        title="Bayroq — sharaf, ehtirom — burch"
        lead="Davlat bayrogʻi nafaqat ramz, balki suveren davlatning huquqiy maqomidir. Unga munosabatimiz esa milliy oʻzligimizning kundalik ifodasidir."
      />

      <div className="grid gap-4 sm:grid-cols-2">
        {LEGAL_CARDS.map((c) => (
          <article
            key={c.title}
            className="group rounded-2xl border border-line bg-background p-6 transition-all hover:-translate-y-0.5 hover:border-brand/30 hover:shadow-md"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft text-brand transition-colors group-hover:bg-brand group-hover:text-white">
              <c.icon className="h-5.5 w-5.5" />
            </span>
            <h3 className="mt-4 font-serif text-lg font-semibold text-ink">{c.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{c.text}</p>
          </article>
        ))}
      </div>

      <div className="mt-12 rounded-3xl border border-brand/15 bg-brand-soft/50 p-6 md:p-10">
        <h3 className="text-center font-serif text-2xl font-semibold text-ink md:text-3xl">
          Bayroqqa ehtirom — Vatanga ehtirom
        </h3>
        <p className="mx-auto mt-3 max-w-2xl text-center text-sm leading-relaxed text-muted-foreground md:text-base">
          Milliy gʻurur shunchaki soʻzlarda emas — u kundalik amallarda namoyon boʻladi.
          Bayroqqa boʻlgan hurmatni oʻz oʻrnida bilim olish, halol ishlash va jamiyatga
          foyda keltirish orqali bildiramiz.
        </p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {CIVIC_ITEMS.map((c) => (
            <div
              key={c.title}
              className="rounded-xl border border-line bg-white p-5 shadow-sm"
            >
              <c.icon className="h-5 w-5 text-brand" />
              <h4 className="mt-3 text-[15px] font-bold text-ink">{c.title}</h4>
              <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">
                {c.text}
              </p>
            </div>
          ))}
        </div>
        <p className="mt-8 text-center text-xs text-muted-foreground">
          Batafsil: {LAW_SOURCE.name}, {LAW_SOURCE.meta} —{" "}
          <a
            href={LAW_SOURCE.url}
            target="_blank"
            rel="noopener noreferrer"
            className="font-medium text-brand underline decoration-brand/40 underline-offset-2 hover:decoration-brand"
          >
            lex.uz
          </a>
        </p>
      </div>
    </SectionShell>
  );
}
