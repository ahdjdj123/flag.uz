"use client";

import { useMemo, useState } from "react";
import { BookOpen, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { SEARCH_INDEX, normalizeText } from "@/lib/content";
import { scrollToSection } from "./navbar";

export function SearchDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = normalizeText(query);
    if (q.length < 2) return [];
    return SEARCH_INDEX.filter((e) => {
      const hay = normalizeText(`${e.title} ${e.text} ${e.section}`);
      return q.split(" ").every((w) => hay.includes(w));
    }).slice(0, 12);
  }, [query]);

  const go = (sectionId: string) => {
    onOpenChange(false);
    // Dialog yopilgach ravon oʻtishi uchun biroz kutamiz
    setTimeout(() => scrollToSection(sectionId), 120);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-lg p-0 overflow-hidden bg-card border-line"
        aria-describedby={undefined}
      >
        <DialogHeader className="border-b border-line px-5 py-4">
          <DialogTitle className="flex items-center gap-2 font-serif text-lg text-ink">
            <Search className="h-4 w-4 text-brand" />
            Saytdan qidirish
          </DialogTitle>
        </DialogHeader>
        <div className="px-5 pb-5 pt-4">
          <Input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Masalan: yulduzlar, bayroq qachon qabul qilingan…"
            aria-label="Qidiruv soʻzi"
            className="h-11 border-input bg-white text-[15px]"
          />

          <div className="nice-scroll mt-4 max-h-[46vh] space-y-2 overflow-y-auto pr-1">
            {query.trim().length >= 2 && results.length === 0 && (
              <p className="rounded-lg bg-muted px-4 py-6 text-center text-sm text-muted-foreground">
                “{query}” boʻyicha hech narsa topilmadi. Boshqa soʻz bilan urinib koʻring.
              </p>
            )}
            {query.trim().length < 2 && (
              <p className="rounded-lg bg-muted px-4 py-6 text-center text-sm text-muted-foreground">
                Boʻlimlar, ramzlar, atamalar va savollar boʻyicha izlang. Kamida 2 ta harf kiriting.
              </p>
            )}
            {results.map((r) => (
              <button
                key={r.id}
                onClick={() => go(r.sectionId)}
                className="focusable-ring block w-full rounded-lg border border-line bg-white p-3 text-left transition-colors hover:border-brand/40 hover:bg-brand-soft/60"
              >
                <span className="mb-1 inline-flex items-center gap-1.5 rounded-full bg-brand-soft px-2 py-0.5 text-[11px] font-semibold text-brand-deep">
                  <BookOpen className="h-3 w-3" />
                  {r.section}
                </span>
                <span className="block text-[15px] font-semibold text-ink">{r.title}</span>
                <span className="mt-0.5 line-clamp-2 block text-[13px] leading-snug text-muted-foreground">
                  {r.text}
                </span>
              </button>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
