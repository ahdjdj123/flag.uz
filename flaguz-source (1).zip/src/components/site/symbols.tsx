"use client";

import { useState } from "react";
import { Info, Landmark, Sparkles } from "lucide-react";
import { InteractiveFlag, SYMBOL_LABELS, type SymbolKey } from "@/components/uzbekistan-flag";
import { SYMBOLS } from "@/lib/content";
import { SectionHeader, SectionShell } from "./ui";
import { cn } from "@/lib/utils";

export function SymbolsSection() {
  const [selected, setSelected] = useState<SymbolKey | null>(null);
  const info = SYMBOLS.find((s) => s.key === selected) ?? null;

  return (
    <SectionShell id="ramzlar" tone="ivory">
      <SectionHeader
        index="03"
        eyebrow="Ramzlarni anglash"
        title="Har bir rangning oʻz hikoyasi bor"
        lead="Bayroq elementini — rang zolagini, yarim oyni yoki yulduzlarni tanlang va uning qonuniy xususiyatlari bilan keng tarqalgan ramziy talqinlarini bilib oling."
      />

      <div className="grid items-start gap-8 lg:grid-cols-[1.15fr_0.85fr]">
        {/* Interaktiv bayroq */}
        <div>
          <div className="rounded-2xl border border-line bg-card p-4 shadow-sm sm:p-6">
            <InteractiveFlag
              selected={selected}
              onSelect={(k) => setSelected(selected === k ? null : k)}
              className="w-full h-auto rounded-md"
            />
            <p className="mt-4 text-center text-xs text-muted-foreground">
              Bayroq nisbati 2:1 — qonunga ilova qilingan rasmiy sxema asosida tasvirlangan.
              Elementni tanlash uchun bosing.
            </p>
          </div>

          {/* Elementlar roʻyxati */}
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            {(Object.keys(SYMBOL_LABELS) as SymbolKey[]).map((k) => (
              <button
                key={k}
                onClick={() => setSelected(selected === k ? null : k)}
                aria-pressed={selected === k}
                className={cn(
                  "focusable-ring rounded-full border px-4 py-2 text-sm font-medium transition-colors",
                  selected === k
                    ? "border-brand bg-brand text-white shadow-sm"
                    : "border-line bg-card text-ink hover:border-brand/40 hover:bg-brand-soft"
                )}
              >
                {SYMBOL_LABELS[k]}
              </button>
            ))}
          </div>
        </div>

        {/* Maʼlumot paneli */}
        <div className="lg:sticky lg:top-24">
          {!info ? (
            <div className="flex h-full min-h-[320px] flex-col items-center justify-center rounded-2xl border border-dashed border-brand/30 bg-white/70 p-8 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-soft">
                <Info className="h-6 w-6 text-brand" />
              </span>
              <h3 className="mt-4 font-serif text-xl font-semibold text-ink">
                Elementni tanlang
              </h3>
              <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
                Bayroq ustidagi istalgan rang yoki belgi bosilsa, oʻsha elementning
                joylashuvi, qonunda mustahkamlangan xususiyatlari va ramziy maʼnosi shu
                yerda namoyish etiladi.
              </p>
            </div>
          ) : (
            <article
              key={info.key}
              className="rounded-2xl border border-line bg-card p-6 shadow-sm animate-in fade-in slide-in-from-bottom-2 duration-300"
              aria-live="polite"
            >
              <p className="text-xs font-semibold tracking-[0.2em] text-brand uppercase">
                {SYMBOL_LABELS[info.key]}
              </p>
              <h3 className="mt-1 font-serif text-2xl font-semibold text-ink">{info.name}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                <span className="font-semibold text-ink">Joylashuvi: </span>
                {info.location}
              </p>

              <div className="mt-5 rounded-xl border border-brand/15 bg-brand-soft/50 p-4">
                <p className="mb-2 flex items-center gap-2 text-sm font-bold text-brand-deep">
                  <Landmark className="h-4 w-4" />
                  Qonunda belgilangan
                </p>
                <ul className="space-y-1.5">
                  {info.legal.map((t, i) => (
                    <li key={i} className="flex gap-2 text-[13.5px] leading-relaxed text-ink">
                      <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-brand" aria-hidden="true" />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-4 rounded-xl border border-flag-green/20 bg-[#eef7f0] p-4">
                <p className="mb-2 flex items-center gap-2 text-sm font-bold text-[#1c6b43]">
                  <Sparkles className="h-4 w-4" />
                  Keng tarqalgan ramziy talqin
                </p>
                <ul className="space-y-1.5">
                  {info.interpretation.map((t, i) => (
                    <li key={i} className="flex gap-2 text-[13.5px] leading-relaxed text-ink">
                      <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-flag-green" aria-hidden="true" />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>

              {info.note && (
                <p className="mt-4 flex gap-2 rounded-lg bg-muted p-3 text-xs leading-relaxed text-muted-foreground">
                  <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  {info.note}
                </p>
              )}
            </article>
          )}
        </div>
      </div>
    </SectionShell>
  );
}
