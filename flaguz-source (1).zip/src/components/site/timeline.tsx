"use client";

import { useState } from "react";
import { ScrollText, MousePointerClick } from "lucide-react";
import { SectionHeader, SectionShell } from "./ui";
import { Reveal } from "./reveal";
import { TIMELINE, LAW_SOURCE } from "@/lib/content";
import { cn } from "@/lib/utils";

export function TimelineSection() {
  const [active, setActive] = useState<number | null>(null);

  const choose = (i: number, scroll = false) => {
    setActive(i);
    // Yillar panelidan tanlanganda kartochka koʻrinishda qolishi uchun
    if (scroll && typeof document !== "undefined") {
      const el = document.getElementById(`timeline-item-${i}`);
      el?.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  return (
    <SectionShell id="tarix" tone="white">
      <SectionHeader
        index="02"
        eyebrow="Tarix va mustaqillik"
        title="Mustaqillik ramzining yoʻli"
        lead="Davlat bayrogʻi mustaqillik eʼlon qilingan ilk kunlardan boshlab yangi davlatning rasmiy ramzi sifatida shakllandi. Quyidagi xronologiya faqat tasdiqlangan manbalarga asoslangan."
      />

      {/* Yil tanlash paneli — xronologiyaning qisqa koʻrinishi */}
      <Reveal>
        <div
          className="mx-auto mb-10 flex max-w-3xl flex-wrap items-center justify-center gap-2"
          role="group"
          aria-label="Xronologiya yillari"
        >
          {TIMELINE.map((item, i) => (
            <button
              key={item.date}
              onClick={() => choose(i, true)}
              aria-pressed={active === i}
              className={cn(
                "focusable-ring rounded-full border px-3.5 py-1.5 text-xs font-semibold transition-colors sm:text-[13px]",
                active === i
                  ? "border-brand bg-brand text-white shadow-sm"
                  : "border-line bg-background text-ink hover:border-brand/40 hover:bg-brand-soft"
              )}
            >
              {item.date.replace(/\d{4}-yil /, "")}
            </button>
          ))}
          <span className="ml-1 hidden items-center gap-1.5 text-xs text-muted-foreground sm:inline-flex">
            <MousePointerClick className="h-3.5 w-3.5 text-brand" />
            Sana bosilsa — voqea ajratib koʻrsatiladi
          </span>
        </div>
      </Reveal>

      <ol
        className="relative mx-auto max-w-3xl"
        aria-label="Davlat bayrogʻi tarixi xronologiyasi"
      >
        <span
          className="absolute top-2 bottom-2 left-[11px] w-px bg-gradient-to-b from-brand/60 via-line to-flag-green/50 md:left-1/2"
          aria-hidden="true"
        />
        {TIMELINE.map((item, i) => (
          <li key={item.date} className="relative pb-10 last:pb-0 md:pb-14">
            <div
              className={
                "md:flex md:items-start " +
                (i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse")
              }
            >
              {/* Nuqta */}
              <span
                className="absolute top-1.5 left-0 z-10 flex h-6 w-6 items-center justify-center md:left-1/2 md:-translate-x-1/2"
                aria-hidden="true"
              >
                <span
                  className={cn(
                    "timeline-dot absolute h-6 w-6 rounded-full",
                    active === i ? "bg-brand/25" : "bg-brand/15"
                  )}
                />
                <span
                  className={cn(
                    "timeline-dot relative h-3 w-3 rounded-full ring-2 ring-white",
                    active === i ? "bg-brand" : "bg-brand"
                  )}
                />
              </span>

              <div
                className={
                  "ml-10 md:ml-0 md:w-1/2 " +
                  (i % 2 === 0 ? "md:pr-10" : "md:pl-10")
                }
              >
                <button
                  id={`timeline-item-${i}`}
                  onClick={() => choose(i)}
                  aria-pressed={active === i}
                  className={cn(
                    "timeline-item focusable-ring block w-full rounded-xl border bg-background p-5 text-left shadow-sm hover:shadow-md",
                    active === i
                      ? "is-active border-brand/40"
                      : "border-line"
                  )}
                >
                  <span
                    className={cn(
                      "inline-block rounded-full px-3 py-1 text-xs font-bold tracking-wide transition-colors",
                      active === i
                        ? "bg-brand text-white"
                        : "bg-brand-soft text-brand-deep"
                    )}
                  >
                    {item.date}
                  </span>
                  <h3 className="mt-3 font-serif text-lg font-semibold text-ink md:text-xl">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground md:text-[15px]">
                    {item.text}
                  </p>
                  {active === i && (
                    <p className="mt-3 animate-in fade-in slide-in-from-bottom-1 text-xs font-medium text-brand duration-300">
                      Xronologiya: {i + 1}-bosqich — {TIMELINE.length} ta tasdiqlangan voqeadan
                    </p>
                  )}
                </button>
              </div>
              {/* Ikkinchi ustun boʻsh joy (oʻzgaruvchan joylashuv uchun) */}
              <div className="hidden md:block md:w-1/2" aria-hidden="true" />
            </div>
          </li>
        ))}
      </ol>

      <Reveal>
        <aside className="mx-auto mt-4 flex max-w-3xl items-start gap-3 rounded-xl border border-brand/15 bg-brand-soft/60 p-4 md:mt-8">
          <ScrollText className="mt-0.5 h-5 w-5 shrink-0 text-brand" />
          <p className="text-sm leading-relaxed text-ink">
            <span className="font-semibold">Asosiy manba: </span>
            {LAW_SOURCE.name}, {LAW_SOURCE.meta}.{" "}
            <a
              href={LAW_SOURCE.url}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-brand underline decoration-brand/40 underline-offset-2 hover:decoration-brand"
            >
              lex.uz/uz/acts/-100122
            </a>{" "}
            — qonunning toʻliq matni va bayroqning tasdiqlangan illyustratsiyasi shu
            manbada mavjud.
          </p>
        </aside>
      </Reveal>
    </SectionShell>
  );
}
