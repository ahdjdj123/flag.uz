"use client";

import { cn } from "@/lib/utils";
import { Reveal } from "./reveal";

export function SectionShell({
  id,
  children,
  className,
  tone = "ivory",
}: {
  id: string;
  children: React.ReactNode;
  className?: string;
  tone?: "ivory" | "white";
}) {
  return (
    <section
      id={id}
      className={cn(
        "scroll-mt-20 py-16 md:py-24",
        tone === "ivory" ? "bg-background" : "bg-card",
        className
      )}
    >
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal>{children}</Reveal>
      </div>
    </section>
  );
}

export function SectionHeader({
  index,
  eyebrow,
  title,
  lead,
  align = "center",
}: {
  index?: string;
  eyebrow?: string;
  title: React.ReactNode;
  lead?: React.ReactNode;
  align?: "center" | "left";
}) {
  return (
    <div className={cn("mb-10 md:mb-14", align === "center" ? "text-center" : "text-left")}>
      {eyebrow && (
        <p
          className={cn(
            "mb-3 flex items-center gap-3 text-xs font-semibold tracking-[0.22em] text-brand uppercase",
            align === "center" && "justify-center"
          )}
        >
          {index && <span className="text-[#c8a24a]">{index}</span>}
          <span>{eyebrow}</span>
        </p>
      )}
      <h2 className="font-serif text-3xl md:text-4xl lg:text-[2.75rem] leading-tight font-semibold text-ink">
        {title}
      </h2>
      {lead && (
        <p
          className={cn(
            "mt-4 max-w-2xl text-base md:text-lg text-muted-foreground leading-relaxed",
            align === "center" && "mx-auto"
          )}
        >
          {lead}
        </p>
      )}
      <div
        className={cn(
          "ornament-divider mt-8 w-40",
          align === "center" && "mx-auto"
        )}
        aria-hidden="true"
      />
    </div>
  );
}
