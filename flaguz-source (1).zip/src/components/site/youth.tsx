"use client";

import { BookOpen, FlaskConical, HandCoins, Rocket, ShieldCheck } from "lucide-react";
import { SectionHeader, SectionShell } from "./ui";

const PATHS = [
  {
    icon: BookOpen,
    title: "Taʼlim va bilim",
    text: "Chuqur bilim — kelajak poydevori. Har bir oʻzlashtirilgan fan, oʻqilgan kitob va oʻzlashtirilgan kasb bayroq qadri oshishi yoʻlidagi qadamdir.",
  },
  {
    icon: FlaskConical,
    title: "Fan va ilmiy rivojlanish",
    text: "Yangi tadqiqotlar va kashfiyotlar davlatning intellektual salohiyatini koʻrsatadi — yosh olimlar bugun dunyoga tanilgan Oʻzbekistonni yaratadi.",
  },
  {
    icon: Rocket,
    title: "Innovatsiya va texnologiya",
    text: "Raqamli yechimlar, startap loyihalar va zamonaviy texnologiyalar yoshlar qoʻlida iqtisodiyotning yangi balandliklarga koʻtarilishini taʼminlaydi.",
  },
  {
    icon: HandCoins,
    title: "Halol professional mehnat",
    text: "Har qanday kasbdagi sifatli, halol mehnat — oila, jamiyat va davlat farovonligining asosi. Ishga boʻlgan masʼuliyat Vatanga boʻlgan hurmatning koʻzgusidir.",
  },
  {
    icon: ShieldCheck,
    title: "Javobgar fuqarolik",
    text: "Qonunlarga rioya qilish, qadriyatlarni asrash, oqkoʻngillik va atrofdagilarga gʻamxoʻrlik — bayroq gʻoyasini hayotda tasdiqlashdir.",
  },
];

export function YouthSection() {
  return (
    <SectionShell id="yoshlar" tone="white">
      <SectionHeader
        index="06"
        eyebrow="Yoshlar va kelajak"
        title={
          <>
            Bizning oʻzligimiz. Bizning masʼuliyatimiz.{" "}
            <span className="text-brand">Bizning kelajagimiz.</span>
          </>
        }
        lead="Davlat bayrogʻi shunchaki oq moviy-oq-yashil mato emas — u bugun yashayotgan avlodning Vatan oldidagi javobgarligini doimiy eslatib turadi."
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {PATHS.map((p, i) => (
          <article
            key={p.title}
            className={
              "rounded-2xl border border-line bg-background p-6 transition-all hover:-translate-y-0.5 hover:border-brand/30 hover:shadow-md " +
              (i === 4 ? "sm:col-span-2 lg:col-span-1" : "")
            }
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#eef3ee] text-[#1c6b43]">
              <p.icon className="h-5.5 w-5.5" />
            </span>
            <h3 className="mt-4 font-serif text-lg font-semibold text-ink">{p.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.text}</p>
          </article>
        ))}
      </div>

      <blockquote className="mx-auto mt-12 max-w-3xl rounded-2xl border-l-4 border-brand bg-brand-soft/60 p-6 md:p-8">
        <p className="font-serif text-lg leading-relaxed text-ink md:text-xl">
          Bizning oʻzligimiz — bayroqning uch rangida, bizning masʼuliyatimiz — har kungi
          bilim va mehnatimizda, bizning kelajagimiz — esa ana shu qadamlarning yigʻindisida.
          Bayroq osmonda bir marta koʻtarilgan emas — u har birimizning faoliyatimizda
          har kungi kun koʻtarilib turadi.
        </p>
      </blockquote>
    </SectionShell>
  );
}
