"use client";

import { useId, useState } from "react";

/**
 * Akkurate Davlat bayrogʻi geometriyasi.
 *
 * Manba: "Oʻzbekiston Respublikasining Davlat bayrogʻi toʻgʻrisida"gi Qonun
 * (1991-yil 18-noyabr, 407-XII-son) 1-qoʻshimasidagi tasdiqlangan sxema — lex.uz.
 *
 * Sxemadan olingan rasmiy oʻlchamlar (bayroq 250 x 125 sm, nisbat 2:1):
 *  - Zolaklar: moviy 0–40 sm, qizil hoshiya 40–42,5 sm, oq 42,5–82,5 sm,
 *    qizil hoshiya 82,5–85 sm, yashil 85–125 sm.
 *  - Yarim oy: tashqi aylana Ø 30 sm (r=15), eng chap nuqtasi dastadan 20 sm,
 *    zolak boʻyicha markazda; ichki aylana markazi 3,5 sm oʻngga surilgan.
 *  - Yulduzlar: 12 ta, tashqi aylana Ø 6 sm, 5 ustun (orasi 12 sm, oʻng ustun
 *    markazi dastadan 92 sm), 3 qator (orasi 12 sm): yuqori 3, oʻrta 4, pastki 5.
 *
 * SVG koordinatalari: 1 sm = 4 birlik (viewBox 0 0 1000 500).
 */

export const FLAG_COLORS = {
  blue: "#0099B5",
  white: "#FFFFFF",
  red: "#CE1126",
  green: "#1EB53A",
} as const;

// Yulduzlar markazlari (SVG birliklarida): 5 ustun x 3 qator, oʻngda tekislangan
const STAR_COLUMNS = [176, 224, 272, 320, 368]; // 44..92 sm
const STAR_ROWS = [32, 80, 128]; // 8, 20, 32 sm
const STAR_CENTERS: Array<[number, number]> = [
  ...STAR_COLUMNS.slice(2).map((x) => [x, STAR_ROWS[0]] as [number, number]), // yuqori qator: 3
  ...STAR_COLUMNS.slice(1).map((x) => [x, STAR_ROWS[1]] as [number, number]), // oʻrta qator: 4
  ...STAR_COLUMNS.map((x) => [x, STAR_ROWS[2]] as [number, number]), // pastki qator: 5
];

export const STAR_COUNT = STAR_CENTERS.length; // 12

function starPath(cx: number, cy: number, R: number): string {
  const r = R * 0.382; // ichki radius
  const pts: string[] = [];
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const rad = i % 2 === 0 ? R : r;
    pts.push(`${(cx + rad * Math.cos(a)).toFixed(2)},${(cy + rad * Math.sin(a)).toFixed(2)}`);
  }
  return `M${pts.join("L")}Z`;
}

// Yarim oy konturi (tashqi + ichki aylana, evenodd)
const CRESCENT_PATH =
  "M80,80a60,60 0 1,0 120,0a60,60 0 1,0 -120,0 M96.4,80a57.6,57.6 0 1,1 115.2,0a57.6,57.6 0 1,1 -115.2,0";

export type SymbolKey = "blue" | "white" | "green" | "red" | "crescent" | "stars";

export const SYMBOL_LABELS: Record<SymbolKey, string> = {
  blue: "Moviy rang",
  white: "Oq rang",
  green: "Yashil rang",
  red: "Qizil hoshiyalar",
  crescent: "Yarim oy",
  stars: "Oʻn ikki yulduz",
};

function HighlightOutline({ k, stroke }: { k: SymbolKey; stroke: string }) {
  const common = {
    fill: "none",
    stroke,
    strokeWidth: 4,
    strokeDasharray: "10 7",
    strokeLinejoin: "round" as const,
    pointerEvents: "none" as const,
  };
  switch (k) {
    case "blue":
      return <rect x={2} y={2} width={996} height={156} rx={4} {...common} />;
    case "white":
      return <rect x={2} y={172} width={996} height={156} rx={4} {...common} />;
    case "green":
      return <rect x={2} y={342} width={996} height={156} rx={4} {...common} />;
    case "red":
      return (
        <g {...common}>
          <rect x={2} y={157} width={996} height={16} rx={3} />
          <rect x={2} y={327} width={996} height={16} rx={3} />
        </g>
      );
    case "crescent":
      return <path d={CRESCENT_PATH} fillRule="evenodd" {...common} />;
    case "stars":
      return <rect x={158} y={8} width={234} height={144} rx={8} {...common} />;
  }
}

function SelectionMask({ k, id }: { k: SymbolKey; id: string }) {
  const black = { fill: "black" as const };
  switch (k) {
    case "blue":
      return (
        <mask id={id}>
          <rect width="1000" height="500" fill="white" />
          <rect x={0} y={0} width={1000} height={160} {...black} />
        </mask>
      );
    case "white":
      return (
        <mask id={id}>
          <rect width="1000" height="500" fill="white" />
          <rect x={0} y={170} width={1000} height={160} {...black} />
        </mask>
      );
    case "green":
      return (
        <mask id={id}>
          <rect width="1000" height="500" fill="white" />
          <rect x={0} y={340} width={1000} height={160} {...black} />
        </mask>
      );
    case "red":
      return (
        <mask id={id}>
          <rect width="1000" height="500" fill="white" />
          <rect x={0} y={160} width={1000} height={10} {...black} />
          <rect x={0} y={330} width={1000} height={10} {...black} />
        </mask>
      );
    case "crescent":
      return (
        <mask id={id}>
          <rect width="1000" height="500" fill="white" />
          <path d={CRESCENT_PATH} fillRule="evenodd" {...black} />
        </mask>
      );
    case "stars":
      return (
        <mask id={id}>
          <rect width="1000" height="500" fill="white" />
          {STAR_CENTERS.map(([x, y], i) => (
            <path key={i} d={starPath(x, y, 12)} {...black} />
          ))}
        </mask>
      );
  }
}

/** Oddiy, qonunga mos bayroq (interaktiv boʻlmagan variant). */
export function UzbekistanFlag({
  className,
  label = "Oʻzbekiston Respublikasining Davlat bayrogʻi",
}: {
  className?: string;
  label?: string;
}) {
  return (
    <svg
      viewBox="0 0 1000 500"
      className={className}
      role="img"
      aria-label={label}
      preserveAspectRatio="xMidYMid meet"
    >
      <rect width="1000" height="160" fill={FLAG_COLORS.blue} />
      <rect y="160" width="1000" height="10" fill={FLAG_COLORS.red} />
      <rect y="170" width="1000" height="160" fill={FLAG_COLORS.white} />
      <rect y="330" width="1000" height="10" fill={FLAG_COLORS.red} />
      <rect y="340" width="1000" height="200" fill={FLAG_COLORS.green} />
      <circle cx="140" cy="80" r="60" fill={FLAG_COLORS.white} />
      <circle cx="154" cy="80" r="57.6" fill={FLAG_COLORS.blue} />
      {STAR_CENTERS.map(([x, y], i) => (
        <path key={i} d={starPath(x, y, 12)} fill={FLAG_COLORS.white} />
      ))}
    </svg>
  );
}

/** Dastaga oʻrnatilgan bayroq (hero uchun). */
export function FlagOnPole({ className }: { className?: string }) {
  return (
    <div className={className}>
      <div className="flex items-stretch h-full">
        {/* Dasta */}
        <div className="relative flex flex-col items-center">
          <div className="w-3.5 h-3.5 rounded-full bg-[#c8a24a] border border-[#a5842f] shadow-sm mt-1" />
          <div className="w-2.5 flex-1 rounded-b-sm bg-gradient-to-r from-[#9aa7b3] via-[#e6ebef] to-[#9aa7b3] shadow" />
        </div>
        {/* Bayroq */}
        <div className="pl-3 pt-2 pb-10 flex items-start">
          <div className="shadow-[0_18px_45px_-18px_rgba(23,43,69,0.45)] rounded-sm overflow-hidden ring-1 ring-black/5">
            <UzbekistanFlag className="w-full h-auto block" />
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Interaktiv bayroq: elementni bosib maʼlumot olish.
 * Tanlangan element yorqin qoladi, qolgan qismi qorayadi (SVG mask yordamida).
 * Bayroq nisbati hech qachon oʻzgarmaydi.
 */
export function InteractiveFlag({
  selected,
  onSelect,
  className,
}: {
  selected: SymbolKey | null;
  onSelect: (k: SymbolKey) => void;
  className?: string;
}) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const maskId = `flagmask-${uid}`;
  const [hovered, setHovered] = useState<SymbolKey | null>(null);

  const hits: Array<{ k: SymbolKey; el: React.ReactNode; label: string }> = [
    {
      k: "blue",
      label: "Moviy rang (yuqori zolak)",
      el: <rect x={0} y={0} width={1000} height={160} />,
    },
    {
      k: "white",
      label: "Oq rang (oʻrta zolak)",
      el: <rect x={0} y={170} width={1000} height={160} />,
    },
    {
      k: "green",
      label: "Yashil rang (pastki zolak)",
      el: <rect x={0} y={340} width={1000} height={200} />,
    },
    {
      k: "red",
      label: "Qizil hoshiyalar",
      el: (
        <>
          <rect x={0} y={154} width={1000} height={22} />
          <rect x={0} y={324} width={1000} height={22} />
        </>
      ),
    },
    {
      k: "crescent",
      label: "Yarim oy",
      el: <circle cx={140} cy={80} r={68} />,
    },
    {
      k: "stars",
      label: "Oʻn ikki yulduz",
      el: <rect x={150} y={8} width={250} height={152} />,
    },
  ];

  return (
    <svg
      viewBox="0 0 1000 500"
      className={className}
      role="group"
      aria-label="Davlat bayrogʻining interaktiv tasviri — elementlarni tanlash mumkin"
      preserveAspectRatio="xMidYMid meet"
    >
      <defs>
        <SelectionMask k={selected ?? "blue"} id={maskId} />
      </defs>

      {/* Bayroqning oʻzi — hech qanday deformasiyasiz */}
      <rect width="1000" height="160" fill={FLAG_COLORS.blue} />
      <rect y="160" width="1000" height="10" fill={FLAG_COLORS.red} />
      <rect y="170" width="1000" height="160" fill={FLAG_COLORS.white} />
      <rect y="330" width="1000" height="10" fill={FLAG_COLORS.red} />
      <rect y="340" width="1000" height="200" fill={FLAG_COLORS.green} />
      <circle cx="140" cy="80" r="60" fill={FLAG_COLORS.white} />
      <circle cx="154" cy="80" r="57.6" fill={FLAG_COLORS.blue} />
      {STAR_CENTERS.map(([x, y], i) => (
        <path key={i} d={starPath(x, y, 12)} fill={FLAG_COLORS.white} />
      ))}

      {/* Tanlangan elementdan boshqasini qoraytirish */}
      {selected && (
        <rect
          width="1000"
          height="500"
          fill="#172B45"
          opacity="0.5"
          mask={`url(#${maskId})`}
          style={{ pointerEvents: "none" }}
        />
      )}

      {/* Sichqoncha ostidagi element koʻrsatkichi */}
      {hovered && hovered !== selected && (
        <HighlightOutline k={hovered} stroke="rgba(255,255,255,0.85)" />
      )}
      {selected && (
        <g className="flag-selected-outline">
          <HighlightOutline k={selected} stroke="#172B45" />
        </g>
      )}

      {/* Bosish maydonlari (klaviatura bilan ham ishlaydi) */}
      {hits.map((h) => (
        <g
          key={h.k}
          role="button"
          tabIndex={0}
          aria-pressed={selected === h.k}
          aria-label={h.label}
          className="flag-hit"
          fill="transparent"
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onSelect(h.k);
            }
          }}
          onClick={() => onSelect(h.k)}
          onMouseEnter={() => setHovered(h.k)}
          onMouseLeave={() => setHovered(null)}
          onFocus={() => setHovered(h.k)}
          onBlur={() => setHovered(null)}
        >
          {h.el}
          <title>{h.label}</title>
        </g>
      ))}
    </svg>
  );
}
