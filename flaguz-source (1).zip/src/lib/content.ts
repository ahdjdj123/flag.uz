import type { SymbolKey } from "@/components/uzbekistan-flag";

/* ============================================================
   FLAG.UZ — Kontent kutubxonasi (oʻzbek tili, lotin yozuvi)
   Manba: "Oʻzbekiston Respublikasining Davlat bayrogʻi toʻgʻrisida"gi
   Qonun, 1991-yil 18-noyabr, 407-XII-son (lex.uz/uz/acts/-100122)
   ============================================================ */

export const LAW_SOURCE = {
  name: "“Oʻzbekiston Respublikasining Davlat bayrogʻi toʻgʻrisida”gi Qonun",
  meta: "1991-yil 18-noyabr, 407-XII-son",
  url: "https://lex.uz/uz/acts/-100122",
};

/* ---------------- 02 — TARIX ---------------- */

export interface TimelineItem {
  date: string;
  title: string;
  text: string;
}

export const TIMELINE: TimelineItem[] = [
  {
    date: "1991-yil 31-avgust",
    title: "Mustaqillik eʼlon qilindi",
    text: "Oʻzbekiston Respublikasi Oliy Kengashi davlat mustaqilligini eʼlon qiluvchi hujjatni qabul qildi. Yangi suveren davlat oʻzining konstitutsiyaviy asoslariga ega boʻldi va oʻz davlat ramzlarini belgilash vazifasi oldiga turdi.",
  },
  {
    date: "1991-yil 18-noyabr",
    title: "Davlat bayrogʻi qabul qilindi",
    text: "“Oʻzbekiston Respublikasining Davlat bayrogʻi toʻgʻrisida”gi Qonun (407-XII-son) qabul qilindi. Qonunga muvofiq bayroq moviy, oq va yashil rangdagi uch zolakdan, yarim oy va oʻn ikki yulduz tasviridan iborat boʻldi. Qonunga bayroqning tasdiqlangan sxemasi va rangli illyustratsiyasi ilova qilingan.",
  },
  {
    date: "1991-yil 29-dekabr",
    title: "Mustaqillik referendumda tasdiqlandi",
    text: "Umumxalq referendumda Oʻzbekiston Respublikasining davlat mustaqilligi haqidagi natijalar xalq irodasi asosida tasdiqlandi. Shu tariqa yangi davlat va uning ramzlari xalq vakillari tomonidan maʼqullangan boʻldi.",
  },
  {
    date: "1992-yil 2-mart",
    title: "Bayroq xalqaro maydonda",
    text: "Oʻzbekiston Birlashgan Millatlar Tashkilotiga aʼzo boʻldi. Davlat bayrogʻi BMT shtab-kvartirasidagi bayroq alloyi qatorida koʻtarildi — Oʻzbekiston xalqaro huquqning toʻlaqonli subʼekti sifatida tan olindi.",
  },
  {
    date: "1992-yil 8-dekabr",
    title: "Konstitutsion mustahkamlanish",
    text: "Oʻzbekiston Respublikasining Konstitutsiyasi qabul qilindi. Davlat bayrogʻi, gerb va madhiya davlat ramzlari sifatida Konstitutsiya bilan muhofaza qilinadigan maqomga ega boʻldi.",
  },
];

/* ---------------- 03 — RAMZLAR ---------------- */

export interface SymbolInfo {
  key: SymbolKey;
  name: string;
  location: string;
  legal: string[];
  interpretation: string[];
  note?: string;
}

export const SYMBOLS: SymbolInfo[] = [
  {
    key: "blue",
    name: "Moviy rang",
    location: "Bayroqning yuqori zolagi — moviy, yarim oy va yulduzlar ana shu zolakda joylashgan.",
    legal: [
      "Bayroq uchta teng zolakdan iborat; yuqori zolak moviy rangda.",
      "Zolak eni 40 sm (bayroq eni 125 sm, uzunligi 250 sm).",
      "Qonunga bayroqning tasdiqlangan rangli illyustratsiyasi ilova qilingan.",
    ],
    interpretation: [
      "Moviy rang koʻk osmon va suv ramzi sifatida talqin qilinadi.",
      "Suv hayot manbai boʻlgani kabi, moviy rang hayotning davomiyligi, maʼnaviy poklik va yuksaklik ramzi hisoblanadi.",
    ],
    note: "Qonun ranglarning rasmiy talqinini matn sifatida belgilab qoʻymagan — bu talqinlar umumqabul qilingan manbalarga asoslanadi.",
  },
  {
    key: "white",
    name: "Oq rang",
    location: "Bayroqning oʻrta zolagi — yuqori va pastki qizil hoshiyalar orasida joylashgan.",
    legal: [
      "Oʻrta zolak oq rangda, eni 40 sm.",
      "Oq zolak yuqorida va pastdan ikkitadan qizil hoshiya bilan chegaralangan.",
    ],
    interpretation: [
      "Oq rang anʼanaviy ravishda tinchlik va osoyishtalik ramzi hisoblanadi.",
      "Shuningdek, maʼnaviy poklik, ochiq niyat va ezgulik ramzi sifatida izohlanadi.",
    ],
  },
  {
    key: "green",
    name: "Yashil rang",
    location: "Bayroqning pastki zolagi — uchta zolakning oxirgisi.",
    legal: ["Pastki zolak yashil rangda, eni 40 sm.", "Zolaklar bayroq eni boʻylab teng taqsimlangan."],
    interpretation: [
      "Yashil rang tabiat va yashillik ramzi sifatida talqin qilinadi.",
      "Shuningdek, unum-barvoylik, yangilanish va davomiy hayot ramzi hisoblanadi.",
    ],
  },
  {
    key: "red",
    name: "Qizil hoshiyalar",
    location: "Oq zolakni yuqoridagi moviy va pastdagi yashil zolakdan ajratib turuvchi ikkita tor chiziq.",
    legal: [
      "Oq zolak ikkita qizil hoshiya bilan chegaralangan.",
      "Har bir hoshiyaning eni 2,5 sm.",
    ],
    interpretation: [
      "Rasmiy tushuntirishlarda qizil rang hayotiy kuch va hayotning uzluksizligi ramzi sifatida izohlanadi.",
      "Hoshiyalar uch zolakni yaxlit bir ramzga birlashtiruvchi bogʻlovchi vazifani bajaradi.",
    ],
  },
  {
    key: "crescent",
    name: "Yarim oy",
    location: "Moviy zolakning dastaga yaqin qismida; qavariq tomoni bayroq dastasiga qaratilgan.",
    legal: [
      "Tasdiqlangan sxemaga koʻra yarim oyning tashqi aylanasi diametri 30 sm.",
      "Tashqi aylananing eng yaqin nuqtasi bayroq dastasidan 20 sm masofada joylashgan.",
      "Yarim oy moviy zolak boʻyicha markazda joylashgan boʻlib, ichki aylana markazi 3,5 sm ga surilgan.",
    ],
    interpretation: [
      "Yarim oy qadimdan turkiy xalqlar madaniyati va maʼnaviy anʼanalarida muhim ramz boʻlib kelgan.",
      "Keng tarqalgan talqinga koʻra, yarim oy mustaqilligi yangi eʼlon qilingan davlatning tugʻilishini va uning kelajakka yoʻl olgan yuksalishini ifodalaydi.",
    ],
    note: "Yarim oyning aynan mazmuni qonun matnida izohlanmagan. Turli manbalarda turlicha talqin qilinishi mumkin.",
  },
  {
    key: "stars",
    name: "Oʻn ikki yulduz",
    location: "Yarim oyning oʻng tomonida, moviy zolakda uch qatorga joylashgan.",
    legal: [
      "Bayroqda 12 ta oq, besh burchakli yulduz bor.",
      "Yulduzlar uch qatorda: yuqori qatorda 3 ta, oʻrta qatorda 4 ta, pastki qatorda 5 ta.",
      "Tasdiqlangan sxemaga koʻra yulduzlarni oʻz ichiga olgan aylana diametri 6 sm.",
    ],
    interpretation: [
      "Eng keng tarqalgan talqinga koʻra, 12 yulduz yilning 12 oyi ramzi hisoblanadi.",
      "Yulduzlar shuningdek qadimgi turkiy taqvim va mahalliy maʼnaviy anʼanalar bilan bogʻlanadi.",
    ],
    note: "Yulduzlar sonining rasmiy izohi qonunda keltirilmagan — turli talqinlar mavjudligini hisobga olish lozim.",
  },
];

/* ---------------- 05 — BILIMLAR SINOVI ---------------- */

export interface QuizQuestion {
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

export const QUIZ: QuizQuestion[] = [
  {
    question: "Oʻzbekiston Respublikasining Davlat bayrogʻi qachon qabul qilingan?",
    options: [
      "1991-yil 31-avgust",
      "1991-yil 18-noyabr",
      "1991-yil 29-dekabr",
      "1992-yil 8-dekabr",
    ],
    correct: 1,
    explanation:
      "“Oʻzbekiston Respublikasining Davlat bayrogʻi toʻgʻrisida”gi Qonun 1991-yil 18-noyabrda qabul qilingan (407-XII-son). 31-avgust — mustaqillik eʼlon qilingan kun, 29-dekabr — mustaqillik boʻyicha referendum oʻtkazilgan kun, 8-dekabr esa Konstitutsiya qabul qilingan kun.",
  },
  {
    question: "Davlat bayrogʻining uzunligi va eni nisbati qanday?",
    options: ["3:2", "2:1", "1:1", "5:2"],
    correct: 1,
    explanation:
      "Qonunga koʻra bayroq uzunligi 250 sm, eni 125 sm, yaʼni nisbat aynan 2:1. Bu nisbat bayroqning har qanday nusxasida saqlanishi shart.",
  },
  {
    question: "Bayroq qanday rangli zolaklardan va qanday tartibda iborat?",
    options: [
      "Oq, moviy, yashil — yuqoridan pastga",
      "Moviy, oq, yashil — yuqoridan pastga",
      "Yashil, oq, moviy — yuqoridan pastga",
      "Moviy, yashil, oq — yuqoridan pastga",
    ],
    correct: 1,
    explanation:
      "Bayroq boʻylab choʻzilgan uchta teng zolakdan iborat: yuqorida moviy, oʻrtada oq va pastda yashil zolak joylashgan.",
  },
  {
    question: "Oq zolak qanday hoshiyalar bilan chegaralangan?",
    options: [
      "Bitta moviy hoshiya bilan",
      "Ikkita yashil hoshiya bilan",
      "Ikkita qizil hoshiya bilan",
      "Hoshiyasiz, boʻsh qoldirilgan",
    ],
    correct: 2,
    explanation:
      "Oq zolak yuqorida va pastdan ikkita qizil hoshiya bilan chegaralangan. Har bir hoshiyaning eni 2,5 sm.",
  },
  {
    question: "Yarim oyning qavariq tomoni qaysi tomonga qaratilgan?",
    options: [
      "Bayroq dastasi tomon",
      "Dastadan uzoq tomon (oʻngga)",
      "Yuqoriga",
      "Pastga",
    ],
    correct: 0,
    explanation:
      "Qonunga ilova qilingan tasdiqlangan sxemaga koʻra, yarim oy bayroqning dastaga yaqin qismida joylashgan va qavariq tomoni dastaga qaratilgan.",
  },
  {
    question: "Davlat bayrogʻida nechta yulduz tasvirlangan?",
    options: ["10 ta", "12 ta", "14 ta", "15 ta"],
    correct: 1,
    explanation:
      "Bayroqda aynan 12 ta oq, besh burchakli yulduz bor. Yulduzlar yarim oyning oʻng tomonida, uch qatorda joylashgan.",
  },
  {
    question: "Yulduzlar qatorlari yuqoridan pastga qarab qanday taqsimlangan?",
    options: ["4, 4, 4", "5, 4, 3", "3, 4, 5", "2, 4, 6"],
    correct: 2,
    explanation:
      "Yulduzlar uch qatorda joylashgan: yuqori qatorda 3 ta, oʻrta qatorda 4 ta va pastki qatorda 5 ta yulduz.",
  },
  {
    question: "Davlat bayrogʻining qonuniy maqomi nimada ifodalanadi?",
    options: [
      "Bayroq faqat davlat idoralarini bezash uchun moʻljallangan",
      "Bayroq davlat suverenitetining ramzi boʻlib, mamlakatni xalqaro maydonda ifodalaydi",
      "Bayroqning maqomi faqat ichki tadbirlar bilan cheklangan",
      "Bayroq oʻrnatilgan joyiga qarab har xil maqomga ega",
    ],
    correct: 1,
    explanation:
      "Davlat bayrogʻi suveren davlatning rasmiy ramzi: u Oʻzbekistonni xalqaro munosabatlarda, tashkilotlarda va rasmiy marosimlarda ifodalaydi. Uning maqomi qonun bilan belgilangan.",
  },
  {
    question: "Oʻzbekiston Davlat bayrogʻi BMTga aʼzolik munosabati bilan xalqaro maydonda qachon koʻtarildi?",
    options: [
      "1991-yil 18-noyabr",
      "1991-yil 18-dekabr",
      "1992-yil 2-mart",
      "1992-yil 8-dekabr",
    ],
    correct: 2,
    explanation:
      "1992-yil 2-martda Oʻzbekiston Birlashgan Millatlar Tashkilotiga aʼzo boʻldi va Davlat bayrogʻi xalqaro maydonda koʻtarildi.",
  },
  {
    question: "Davlat ramzlariga munosabat boʻyicha qaysi xulq-atvor toʻgʻri hisoblanadi?",
    options: [
      "Bayroqni reklama bezagi sifatida oʻzgartirib ishlatish",
      "Bayroq nusxasini zarar yetkazib saqlash",
      "Bayroqdan qonunda belgilangan qoidalar asosida ehtirom bilan foydalanish",
      "Bayroqni kundalik uy-roʻzgʻor buyumi oʻrnida ishlatish",
    ],
    correct: 2,
    explanation:
      "Davlat ramzlari qonun bilan muhofaza qilinadi: ularning maqomini kamsituvchi harakatlar taqiqlangan. Bayroqdan belgilangan tartibda, ehtirom bilan foydalanish har bir fuqaroning burchidir.",
  },
];

/* ---------------- QOʻSHIMCHA BOʻLIMLAR ---------------- */

export interface FaqItem {
  question: string;
  answer: string;
}

export const FAQ: FaqItem[] = [
  {
    question: "FLAG.UZ qanday platforma?",
    answer:
      "FLAG.UZ — Oʻzbekiston Respublikasining Davlat bayrogʻi tarixi, tuzilishi, ramziy talqinlari va huquqiy ahamiyatini interaktiv shaklda oʻrganish uchun yaratilgan taʼlimiy veb-platforma.",
  },
  {
    question: "Platformadan foydalanish pullikmi?",
    answer:
      "Hozirgi vaqtda FLAG.UZ bepul foydalanish uchun taqdim etilgan. Platformaning tajriba versiyasidan foydalanish uchun obuna yoki toʻlov talab qilinmaydi.",
  },
  {
    question: "FLAG.UZ yakuniy mahsulotmi?",
    answer:
      "Yoʻq. Hozirgi versiya tajriba va dastlabki foydalanish uchun moʻljallangan. Platformaning ayrim funksiyalari, dizayni va mazmuni kelgusida takomillashtirilishi mumkin.",
  },
  {
    question: "Platforma kameradan foydalanadimi?",
    answer:
      "Yoʻq. FLAG.UZ platformasining ishlashi uchun kamera kerak emas. Platforma kamera ruxsatini soʻramaydi va undan foydalanmaydi.",
  },
  {
    question: "Platforma mikrofon yoki joylashuv maʼlumotlariga kirish huquqini soʻraydimi?",
    answer:
      "Yoʻq. Platformaning asosiy taʼlimiy funksiyalari mikrofon yoki foydalanuvchining joylashuv maʼlumotlariga kirishni talab qilmaydi.",
  },
  {
    question: "Foydalanuvchilarning shaxsiy maʼlumotlari yigʻiladimi?",
    answer:
      "Platforma imkon qadar shaxsiy maʼlumotlarni yigʻmasdan ishlashga moʻljallangan. Foydalanuvchi hisobini yaratish talab qilinmaydi. Agar hosting yoki boshqa texnik xizmatlar doirasida ayrim texnik maʼlumotlar qayta ishlansa, bu haqda maxfiylik bayonnomasida aniq maʼlumot beriladi.",
  },
  {
    question: "Platformadagi maʼlumotlar rasmiy manbalarga asoslanganmi?",
    answer:
      "Tarixiy va huquqiy maʼlumotlar tegishli rasmiy manbalar asosida tayyorlanadi. Asosiy huquqiy manbalardan biri — Oʻzbekiston Respublikasining «Davlat bayrogʻi toʻgʻrisida»gi Qonunidir. Foydalanuvchilarga huquqiy masalalarda rasmiy manbalarga murojaat qilish tavsiya etiladi.",
  },
  {
    question: "FLAG.UZ davlat tashkiloti tomonidan ishlab chiqilganmi?",
    answer:
      "Yoʻq. FLAG.UZ mustaqil taʼlimiy loyiha boʻlib, davlat tashkilotining rasmiy veb-sayti yoki davlat tomonidan tasdiqlangan mahsulot sifatida taqdim etilmaydi.",
  },
  {
    question: "Platformada texnik muammolar yuzaga kelsa nima qilish kerak?",
    answer:
      "FLAG.UZ tajriba versiyasi boʻlgani sababli ayrim texnik nosozliklar kuzatilishi mumkin. Bunday holatlarda platformaning keyingi versiyalarida tegishli kamchiliklarni bartaraf etish va ishlash sifatini yaxshilash koʻzda tutiladi.",
  },
  {
    question: "Platforma kelgusida yangilanadimi?",
    answer:
      "Ha. Loyiha foydalanuvchi tajribasi, taʼlimiy ehtiyojlar va texnik imkoniyatlardan kelib chiqib bosqichma-bosqich takomillashtirilishi rejalashtirilgan.",
  },
];

export interface GlossaryTerm {
  term: string;
  definition: string;
}

export const GLOSSARY: GlossaryTerm[] = [
  {
    term: "Davlat suvereniteti",
    definition:
      "Davlatning ichki va tashqi siyosatda mustaqil qaror qabul qilish huquqi va qobiliyati. Davlat bayrogʻi ana shu suverenitetning koʻrinadigan ramzidir.",
  },
  {
    term: "Davlat ramzi",
    definition:
      "Davlatning rasmiy belgisi boʻlib xizmat qiluvchi, qonun bilan maqomi mustahkamlangan tasvir — Oʻzbekistonda bayroq, gerb va madhiya davlat ramzlari hisoblanadi.",
  },
  {
    term: "Mustaqillik",
    definition:
      "Xalqning oʻz taqdirini oʻzi belgilashi, davlatning tashqi kuchlarga qaram boʻlmagan holda faoliyat yuritishi. Oʻzbekiston mustaqilligi 1991-yil 31-avgustda eʼlon qilingan.",
  },
  {
    term: "Milliy oʻzlik",
    definition:
      "Xalqning tarixiy xotirasi, tili, madaniyati va qadriyatlariga boʻlgan umumiy mansublik hissi. Davlat ramzlari milliy oʻzlikning vizual ifodasidir.",
  },
  {
    term: "Fuqarolik masʼuliyati",
    definition:
      "Har bir fuqaroning jamiyat, davlat va uning qonunlari oldidagi burchini ongli bajarishi — taʼlim olish, halol mehnat qilish, qonunlarga rioya qilish va oʻz Vataniga munosib xizmat qilish.",
  },
  {
    term: "Zolak",
    definition:
      "Bayroq matosida boʻylab choʻzilgan rangli polosa. Oʻzbekiston bayrogʻi uchta teng zolakdan: moviy, oq va yashil zolaklardan iborat.",
  },
  {
    term: "Hoshiya",
    definition:
      "Zolaklarni ajratib turuvchi tor rangli chiziq. Oʻzbekiston bayrogʻida oq zolak ikkita 2,5 sm enli qizil hoshiya bilan chegaralangan.",
  },
];

export const REFERENCES = [
  {
    title: "“Oʻzbekiston Respublikasining Davlat bayrogʻi toʻgʻrisida”gi Qonun",
    meta: "1991-yil 18-noyabr, 407-XII-son — tasdiqlangan sxema va rangli illyustratsiya bilan",
    url: "https://lex.uz/uz/acts/-100122",
  },
  {
    title: "Oʻzbekiston Respublikasining Konstitutsiyasi",
    meta: "1992-yil 8-dekabrda qabul qilingan — Davlat bayrogʻi davlat ramzlari qatorida Konstitutsiya bilan muhofaza qilinadi",
    url: "https://lex.uz/uz/docs/-6445145",
  },
  {
    title: "“Davlat bayrogʻi toʻgʻrisida”gi Qonunga kiritilgan oʻzgartirishlar",
    meta: "2023-yilgi oʻzgartirish va qoʻshimchalar — dolzarb tahrir",
    url: "https://lex.uz/uz/docs/-6524722",
  },
];

export const TEAM = [
  { role: "Loyiha muvofiqlashtiruvchisi", name: "Ism Familiya" },
  { role: "Tarixiy tadqiqot va huquqiy manbalar", name: "Ism Familiya" },
  { role: "Bayroq dizayni va ramzlar", name: "Ism Familiya" },
  { role: "Sinov ishlanmalari va taʼlimiy kontent", name: "Ism Familiya" },
];

/* ---------------- LOYIHA HAQIDA ---------------- */

export const ABOUT_TEXT =
  "FLAG.UZ — Oʻzbekiston Respublikasining Davlat bayrogʻi tarixi, rasmiy tuzilishi, huquqiy ahamiyati va ramziy talqinlarini oʻquvchilarga interaktiv shaklda yetkazish uchun yaratilgan tajribaviy taʼlimiy veb-platforma. Platforma AION loyiha ekotizimi doirasida, ZIYO — 1-guruh tomonidan ishlab chiqilgan.";

export const EXPERIMENTAL_POINTS = [
  "Hozirgi veb-sayt tajriba (sinov) versiyasidir — u toʻliq yakunlangan tijorat mahsuloti emas.",
  "Ayrim funksiyalar, dizayn va mazmun keyingi versiyalarda takomillashtirilishi yoki oʻzgartirilishi mumkin.",
  "Vaqtincha texnik nosozliklar kuzatilishi mumkin.",
  "Yangi yaxshilanishlar va imkoniyatlar kelgusi versiyalarda joriy etiladi.",
  "Huquqiy maʼlumotlar uchun rasmiy manbalarga murojaat qilish tavsiya etiladi.",
];

export const FREE_NOTICE =
  "FLAG.UZ hozirda bepul foydalanish uchun taqdim etilgan tajriba loyihasidir.";

export const PRIVACY_POINTS = [
  "Platforma ishlashi uchun kameraga kirish talab qilinmaydi; kamera ruxsati soʻralmaydi va undan foydalanilmaydi.",
  "Mikrofon, joylashuv, kontaktlar, shaxsiy fayllar va fot suratlarga kirish huquqi soʻralmaydi.",
  "Oddiy taʼlimiy foydalanish uchun roʻyxatdan oʻtish yoki hisob yaratish talab qilinmaydi.",
  "Platforma reklam va uchinchi shaxslarga yoʻnaltirilgan kuzatuv mexanizmlaridan foydalanmaydi.",
];

export const PRIVACY_DATA_NOTE =
  "Test natijalari va sozlamalar faqat sizning qurilmangizda, brauzer xotirasida saqlanadi va serverga yuborilmaydi. Agar xosting yoki boshqa texnik xizmatlar doirasida ayrim texnik maʼlumotlar qayta ishlansa, bu maxfiylik bayonnomasida aniq aks etadi.";

export const PRIVACY_LEGAL_NOTE =
  "Loyiha Oʻzbekiston Respublikasining shaxsiy maʼlumotlar va axborot xavfsizligi sohasidagi qonunchiligi talablarini hisobga olib ishlab chiqiladi va yuritiladi. Platforma davlat organi tomonidan ishlab chiqilgan, tasdiqlangan yoki sertifikatlangan mahsulot emas.";

/* ---------------- QIDIRUV INDEKSI ---------------- */

export interface SearchEntry {
  id: string;
  sectionId: string;
  section: string;
  title: string;
  text: string;
}

export const SEARCH_INDEX: SearchEntry[] = [
  {
    id: "hero",
    sectionId: "bosh-sahifa",
    section: "Bosh sahifa",
    title: "Bir Bayroq. Bir Xalq. Bir Oʻzlik.",
    text: "Oʻzbekiston Respublikasining Davlat bayrogʻi tarixi, ramziy mazmuni va davlat mustaqilligini ifodalashdagi oʻrni. FLAG.UZ taʼlimiy loyihasi.",
  },
  ...TIMELINE.map((t, i) => ({
    id: `timeline-${i}`,
    sectionId: "tarix",
    section: "Tarix va mustaqillik",
    title: `${t.date} — ${t.title}`,
    text: t.text,
  })),
  ...SYMBOLS.map((s) => ({
    id: `symbol-${s.key}`,
    sectionId: "ramzlar",
    section: "Ramzlarni anglash",
    title: s.name,
    text: `${s.location} ${s.legal.join(" ")} ${s.interpretation.join(" ")}`,
  })),
  {
    id: "civic",
    sectionId: "majburiyat",
    section: "Davlat ramzi va fuqarolik masʼuliyati",
    title: "Bayroqning qonuniy maqomi",
    text: "Davlat bayrogʻi suverenitet ramzi, xalqaro maydonda mamlakat vakilligi, ehtirom qoidalari, fuqarolik masʼuliyati, taʼlim va halol mehnat.",
  },
  {
    id: "quiz",
    sectionId: "sinov",
    section: "Bilimlar sinovi",
    title: "Bilimlar sinovi — 10 savol",
    text: "Davlat bayrogʻi qabul qilingan sana, nisbat, zolaklar, hoshiyalar, yarim oy, yulduzlar soni va joylashuvi boʻyicha interaktiv test.",
  },
  {
    id: "youth",
    sectionId: "yoshlar",
    section: "Yoshlar va kelajak",
    title: "Bizning oʻzligimiz, masʼuliyatimiz va kelajagimiz",
    text: "Yoshlarning taʼlim, fan, innovatsiya, halol mehnat va fuqarolik faolligi orqali Oʻzbekiston kelajagiga qoʻshadigan hissasi.",
  },
  ...FAQ.map((f, i) => ({
    id: `faq-${i}`,
    sectionId: "savollar",
    section: "Koʻp beriladigan savollar",
    title: f.question,
    text: f.answer,
  })),
  {
    id: "loyiha-haqida",
    sectionId: "loyiha",
    section: "Loyiha haqida",
    title: "FLAG.UZ — tajribaviy taʼlimiy platforma",
    text: `${ABOUT_TEXT} ${FREE_NOTICE}`,
  },
  {
    id: "maxfiylik",
    sectionId: "loyiha",
    section: "Loyiha haqida",
    title: "Maxfiylik va maʼlumotlar shaffofligi",
    text: "Platforma kamera, mikrofon va joylashuv maʼlumotlariga kirishni soʻramaydi. Shaxsiy maʼlumotlar yigʻilishi imkon qadar cheklangan.",
  },
  ...GLOSSARY.map((g) => ({
    id: `glossary-${g.term}`,
    sectionId: "lugat",
    section: "Atamalar lugʻati",
    title: g.term,
    text: g.definition,
  })),
  {
    id: "manbalar",
    sectionId: "manbalar",
    section: "Manbalar",
    title: "Qonun va rasmiy manbalar",
    text: "Oʻzbekiston Respublikasining Davlat bayrogʻi toʻgʻrisidagi Qonun, 407-XII-son, lex.uz, Konstitutsiya.",
  },
];

/* Matnni qidiruv uchun normallashtirish: turli apostroflarni birlashtirish */
export function normalizeText(s: string): string {
  return s
    .toLowerCase()
    .replace(/[\u2018\u2019\u02BB\u02BC'`´]/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}
